@echo off
chcp 65001 >nul
title BabyGuard AI - Giam Sat An Toan & Giac Ngu Cho Be
cd /d "%~dp0app_core"
call "Khoi_Dong_BabyGuard.bat"
