import sys
"""
BabyGuard AI - Growth & Pediatric Standards Tracker
Quản lý ngày sinh, tính toán tuổi chính xác theo ngày/tuần/tháng,
theo dõi Chiều cao - Cân nặng định kỳ hàng tháng và đối chiếu chuẩn WHO (World Health Organization).
"""

import os
import json
import math
from datetime import datetime, date, timedelta

if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
GROWTH_FILE = os.path.join(BASE_DIR, "baby_growth.json")

# Bảng chuẩn tăng trưởng WHO (WHO Child Growth Standards 0 - 12 tháng)
# Trung vị (Median) và Dải bình thường (-2SD đến +2SD tương đương bách phân vị 3rd - 97th)
WHO_STANDARDS = {
    "boy": {
        # tháng: (weight_median_kg, weight_min_kg, weight_max_kg, length_median_cm, length_min_cm, length_max_cm)
        0: (3.3, 2.5, 4.3, 49.9, 46.3, 53.4),
        1: (4.5, 3.4, 5.7, 54.7, 51.1, 58.4),
        2: (5.6, 4.4, 7.0, 58.4, 54.7, 62.2),
        3: (6.4, 5.1, 7.9, 61.4, 57.6, 65.3),
        4: (7.0, 5.6, 8.6, 63.9, 60.0, 67.8),
        5: (7.5, 6.1, 9.2, 65.9, 61.9, 69.9),
        6: (7.9, 6.4, 9.7, 67.6, 63.6, 71.6),
        7: (8.3, 6.7, 10.2, 69.2, 65.1, 73.2),
        8: (8.6, 7.0, 10.5, 70.6, 66.5, 74.7),
        9: (8.9, 7.2, 10.9, 72.0, 67.7, 76.2),
        10: (9.2, 7.5, 11.2, 73.3, 69.0, 77.6),
        11: (9.4, 7.6, 11.5, 74.5, 70.2, 78.9),
        12: (9.6, 7.8, 11.8, 75.7, 71.3, 80.2),
    },
    "girl": {
        0: (3.2, 2.4, 4.2, 49.1, 45.6, 52.7),
        1: (4.2, 3.2, 5.4, 53.7, 50.0, 57.4),
        2: (5.1, 4.0, 6.4, 57.1, 53.2, 60.9),
        3: (5.8, 4.6, 7.3, 59.8, 55.8, 63.8),
        4: (6.4, 5.1, 8.0, 62.1, 58.0, 66.2),
        5: (6.9, 5.5, 8.7, 64.0, 59.9, 68.2),
        6: (7.3, 5.8, 9.2, 65.7, 61.5, 70.0),
        7: (7.6, 6.1, 9.6, 67.3, 62.9, 71.6),
        8: (7.9, 6.3, 10.0, 68.7, 64.3, 73.1),
        9: (8.2, 6.6, 10.4, 70.1, 65.6, 74.5),
        10: (8.5, 6.8, 10.7, 71.5, 66.9, 76.0),
        11: (8.7, 7.0, 11.0, 72.8, 68.2, 77.4),
        12: (8.9, 7.1, 11.3, 74.0, 69.3, 78.8),
    }
}


def parse_date(date_str: str) -> date:
    """Hỗ trợ phân tích cả định dạng YYYY-MM-DD lẫn DD/MM/YYYY."""
    if not date_str:
        return None
    date_str = str(date_str).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(date_str, fmt).date()
        except ValueError:
            pass
    return None


def calculate_exact_age(birth_date_str: str, target_date: date = None) -> dict:
    """
    Tính tuổi chính xác theo Ngày, Tuần, Tháng từ Ngày Sinh.
    Trả về cấu trúc chi tiết và khuyến nghị sinh lý nhi khoa tương ứng.
    """
    if target_date is None:
        target_date = date.today()

    b_date = parse_date(birth_date_str)
    if not b_date or b_date > target_date:
        # Mặc định sơ sinh 1 tháng nếu chưa nhập hoặc ngày sinh không hợp lệ
        b_date = target_date - timedelta(days=35)

    total_days = max(1, (target_date - b_date).days)
    total_weeks = total_days // 7
    rem_days_in_week = total_days % 7

    # Tính tháng và ngày dư
    # Giả định trung bình 1 tháng ~ 30.4375 ngày
    months_approx = total_days / 30.4375
    full_months = int(months_approx)
    rem_days = int(round((months_approx - full_months) * 30.4375))
    if rem_days >= 30:
        full_months += 1
        rem_days = 0

    if full_months == 0:
        age_display = f"{total_days} ngày tuổi ({total_weeks} tuần {rem_days_in_week} ngày)"
    elif rem_days == 0:
        age_display = f"{full_months} tháng tuổi ({total_days} ngày)"
    else:
        age_display = f"{full_months} tháng {rem_days} ngày ({total_days} ngày tuổi)"

    # Khuyến nghị y khoa theo độ tuổi (AAP & AASM Guidelines)
    if total_days < 30:
        wake_window_min = 35
        wake_window_max = 60
        sleep_need_min = 15.0
        sleep_need_max = 18.0
        naps_count_str = "4 - 5 cữ nap"
        normal_bpm_min = 30
        normal_bpm_max = 60
        age_stage = "Sơ sinh (Newborn 0-1 tháng)"
    elif total_days <= 90:
        wake_window_min = 45
        wake_window_max = 90
        sleep_need_min = 14.0
        sleep_need_max = 17.0
        naps_count_str = "3 - 4 cữ nap"
        normal_bpm_min = 28
        normal_bpm_max = 55
        age_stage = "Trẻ nhỏ (1 - 3 tháng tuổi)"
    elif total_days <= 180:
        wake_window_min = 75
        wake_window_max = 135
        sleep_need_min = 13.0
        sleep_need_max = 16.0
        naps_count_str = "3 cữ nap"
        normal_bpm_min = 24
        normal_bpm_max = 45
        age_stage = "Trẻ 4 - 6 tháng tuổi"
    elif total_days <= 270:
        wake_window_min = 120
        wake_window_max = 180
        sleep_need_min = 12.0
        sleep_need_max = 15.0
        naps_count_str = "2 - 3 cữ nap"
        normal_bpm_min = 22
        normal_bpm_max = 40
        age_stage = "Trẻ 7 - 9 tháng tuổi"
    else:
        wake_window_min = 150
        wake_window_max = 240
        sleep_need_min = 11.5
        sleep_need_max = 14.5
        naps_count_str = "2 cữ nap"
        normal_bpm_min = 20
        normal_bpm_max = 38
        age_stage = "Trẻ 10 - 12+ tháng tuổi"

    return {
        "birth_date": b_date.strftime("%Y-%m-%d"),
        "total_days": total_days,
        "total_weeks": total_weeks,
        "full_months": full_months,
        "rem_days": rem_days,
        "age_display": age_display,
        "age_stage": age_stage,
        "wake_window_min_minutes": wake_window_min,
        "wake_window_max_minutes": wake_window_max,
        "sleep_need_min_hours": sleep_need_min,
        "sleep_need_max_hours": sleep_need_max,
        "naps_count_recommend": naps_count_str,
        "normal_respiratory_rate": f"{normal_bpm_min} - {normal_bpm_max} BPM"
    }


def interpolate_who_standard(gender: str, total_days: int) -> tuple:
    """
    Nội suy tuyến tính (Linear Interpolation) chuẩn WHO theo TỪNG NGÀY TUỔI chính xác (total_days / 30.4375)
    giữa 2 mốc tháng liền kề trong bảng WHO_STANDARDS.
    Trả về: (w_med, w_min, w_max, l_med, l_min, l_max, exact_months_float)
    """
    gender_key = "girl" if str(gender).lower() in ("girl", "gái", "female", "f") else "boy"
    table = WHO_STANDARDS.get(gender_key, WHO_STANDARDS["boy"])
    exact_m = max(0.0, min(12.0, float(total_days) / 30.4375))
    m_low = int(math.floor(exact_m))
    m_high = min(12, m_low + 1)
    frac = exact_m - m_low

    row_low = table.get(m_low, table[0])
    row_high = table.get(m_high, row_low)

    interp = [round(row_low[i] + frac * (row_high[i] - row_low[i]), 2) for i in range(6)]
    # Làm tròn chiều dài (cm) tới 1 chữ số thập phân
    interp[3] = round(interp[3], 1)
    interp[4] = round(interp[4], 1)
    interp[5] = round(interp[5], 1)
    return (interp[0], interp[1], interp[2], interp[3], interp[4], interp[5], round(exact_m, 2))


class GrowthTracker:
    def __init__(self, data_path: str = None):
        self.data_path = data_path or GROWTH_FILE
        self.records = []
        self._load()

    def _load(self):
        if os.path.exists(self.data_path):
            try:
                with open(self.data_path, "r", encoding="utf-8") as f:
                    self.records = json.load(f)
            except Exception:
                self.records = []
        else:
            # Tạo bản ghi mẫu ban đầu lúc sinh nếu chưa có
            self.records = [
                {
                    "date": "2026-09-05",
                    "weight_kg": 3.35,
                    "height_cm": 50.0,
                    "head_circ_cm": 34.5,
                    "note": "Lúc chào đời"
                },
                {
                    "date": "2026-10-05",
                    "weight_kg": 4.60,
                    "height_cm": 54.8,
                    "head_circ_cm": 37.0,
                    "note": "Cữ đầy tháng (1 tháng tuổi)"
                }
            ]
            self._save()

    def _save(self):
        try:
            with open(self.data_path, "w", encoding="utf-8") as f:
                json.dump(self.records, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[GrowthTracker] Lỗi lưu baby_growth.json: {e}")

    def add_record(self, weight_kg: float, height_cm: float, head_circ_cm: float = None,
                   record_date_str: str = None, note: str = "") -> dict:
        """Thêm bản ghi cân nặng, chiều cao định kỳ mới."""
        self._load()
        d = parse_date(record_date_str) or date.today()
        d_str = d.strftime("%Y-%m-%d")

        # Cập nhật nếu đã có bản ghi cùng ngày, hoặc chèn mới
        existing = next((r for r in self.records if r.get("date") == d_str), None)
        new_entry = {
            "date": d_str,
            "weight_kg": round(float(weight_kg), 2),
            "height_cm": round(float(height_cm), 1),
            "head_circ_cm": round(float(head_circ_cm), 1) if head_circ_cm else None,
            "note": note.strip()
        }

        if existing:
            existing.update(new_entry)
        else:
            self.records.append(new_entry)

        # Sắp xếp theo ngày tăng dần
        self.records.sort(key=lambda r: r.get("date", ""))
        self._save()
        return new_entry

    def delete_record(self, record_date_str: str) -> bool:
        """Xóa bản ghi số đo theo ngày."""
        self._load()
        d_str = str(record_date_str).strip()
        initial_count = len(self.records)
        self.records = [r for r in self.records if r.get("date") != d_str]
        if len(self.records) < initial_count:
            self._save()
            return True
        return False

    def get_latest_record(self) -> dict:
        self._load()
        if not self.records:
            return None
        return self.records[-1]

    def should_trigger_monthly_reminder(self) -> dict:
        """
        Kiểm tra điều kiện bật pop-up nhắc nhở ba mẹ:
        1. Hôm nay là Ngày 1 đầu tháng (day == 1) và chưa có bản ghi nào trong 15 ngày qua.
        2. HOẶC nếu ba mẹ đã nhập sớm thì tính từ ngày nhập gần nhất đến nay đã đủ 30 ngày (>= 30 ngày)
           mà chưa có bản ghi bổ sung tiếp theo.
        """
        today = date.today()
        latest = self.get_latest_record()
        
        if not latest:
            return {
                "needs_reminder": True,
                "reason": "Chưa có thông số cân nặng chiều cao ban đầu của bé.",
                "days_since_last": 999
            }

        last_date = parse_date(latest.get("date", ""))
        if not last_date:
            days_since = 999
        else:
            days_since = (today - last_date).days

        # Điều kiện 1: Ngày 1 đầu tháng và trong 15 ngày qua chưa đo
        if today.day == 1 and days_since >= 15:
            return {
                "needs_reminder": True,
                "reason": f"Hôm nay là mùng 1 đầu tháng ({today.strftime('%d/%m/%Y')}). Đã đến kỳ cập nhật Chiều cao & Cân nặng tháng mới cho bé!",
                "days_since_last": days_since,
                "last_date": latest.get("date")
            }

        # Điều kiện 2: Đã trôi qua >= 30 ngày kể từ lần cập nhật gần nhất
        if days_since >= 30:
            return {
                "needs_reminder": True,
                "reason": f"Đã {days_since} ngày kể từ lần ghi nhận gần nhất ({latest.get('date')}). Hãy cập nhật số đo mới để theo dõi tăng trưởng của bé nhé!",
                "days_since_last": days_since,
                "last_date": latest.get("date")
            }

        return {
            "needs_reminder": False,
            "reason": f"Đã cập nhật cách đây {days_since} ngày.",
            "days_since_last": days_since,
            "last_date": latest.get("date")
        }

    def evaluate_growth(self, birth_date_str: str, gender: str = "boy") -> dict:
        """
        Đối chiếu các số đo mới nhất của bé với Tiêu chuẩn Tăng trưởng Trẻ em của WHO (WHO Child Growth Standards)
        sử dụng Nội suy tuyến tính theo từng ngày tuổi và tính tốc độ tăng cân (g/ngày).
        """
        latest = self.get_latest_record()
        if not latest:
            return {"has_data": False}

        latest_date = parse_date(latest.get("date")) or date.today()
        age_info = calculate_exact_age(birth_date_str, target_date=latest_date)
        total_days = age_info["total_days"]
        months = min(12, age_info["full_months"])
        gender_key = "girl" if str(gender).lower() in ("girl", "gái", "female", "f") else "boy"

        w_med, w_min, w_max, l_med, l_min, l_max, exact_m = interpolate_who_standard(gender_key, total_days)
        actual_w = float(latest.get("weight_kg", 0.0))
        actual_l = float(latest.get("height_cm", 0.0))

        # Đánh giá cân nặng đối chiếu chuẩn nội suy WHO (-2SD, Trung vị, +2SD)
        if actual_w < w_min:
            w_status = f"Nhẹ cân so với chuẩn WHO (< {w_min:.1f} kg)"
            w_color = "amber"
        elif actual_w > w_max:
            w_status = f"Vượt trên chuẩn WHO (+2SD > {w_max:.1f} kg)"
            w_color = "cyan"
        elif actual_w < (w_med - 0.25):
            w_status = f"Nằm trong ngưỡng an toàn chuẩn WHO (dưới mức trung vị {w_med:.1f} kg)"
            w_color = "emerald"
        elif actual_w > (w_med + 0.25):
            w_status = f"Nằm trong ngưỡng an toàn chuẩn WHO (trên mức trung vị {w_med:.1f} kg)"
            w_color = "emerald"
        else:
            w_status = f"Đạt chuẩn trung vị WHO ({w_med:.1f} kg - Rất tốt)"
            w_color = "emerald"

        # Đánh giá chiều cao đối chiếu chuẩn nội suy WHO (-2SD, Trung vị, +2SD)
        if actual_l < l_min:
            l_status = f"Thấp hơn chuẩn WHO (-2SD < {l_min:.1f} cm)"
            l_color = "amber"
        elif actual_l > l_max:
            l_status = f"Cao vượt trội so với chuẩn WHO (+2SD > {l_max:.1f} cm)"
            l_color = "cyan"
        elif actual_l < (l_med - 1.2):
            l_status = f"Nằm trong ngưỡng an toàn chuẩn WHO (dưới mức trung vị {l_med:.1f} cm)"
            l_color = "emerald"
        elif actual_l > (l_med + 1.2):
            l_status = f"Nằm trong ngưỡng an toàn chuẩn WHO (trên mức trung vị {l_med:.1f} cm)"
            l_color = "emerald"
        else:
            l_status = f"Đạt chuẩn trung vị chiều cao WHO ({l_med:.1f} cm - Lý tưởng)"
            l_color = "emerald"

        # Tính tốc độ tăng cân trung bình (gram/ngày) từ lúc sinh (records[0]) và từ lần đo trước (records[-2])
        growth_velocity = ""
        velocity_from_birth_g_day = 0.0
        velocity_recent_g_day = 0.0

        if len(self.records) >= 1:
            birth_rec = self.records[0]
            d_birth = parse_date(birth_rec.get("date")) or parse_date(birth_date_str)
            d_curr = parse_date(latest.get("date"))
            if d_birth and d_curr and (d_curr - d_birth).days > 0:
                days_from_birth = (d_curr - d_birth).days
                w_gain_birth_g = (actual_w - float(birth_rec.get("weight_kg", actual_w))) * 1000.0
                velocity_from_birth_g_day = round(w_gain_birth_g / days_from_birth, 1)

        if len(self.records) >= 2:
            prev = self.records[-2]
            d_prev = parse_date(prev.get("date"))
            d_curr = parse_date(latest.get("date"))
            if d_prev and d_curr and (d_curr - d_prev).days > 0:
                days_gap = (d_curr - d_prev).days
                w_gain = actual_w - float(prev.get("weight_kg", 0.0))
                l_gain = actual_l - float(prev.get("height_cm", 0.0))
                velocity_recent_g_day = round((w_gain * 1000.0) / days_gap, 1)
                growth_velocity = (
                    f"Tăng +{w_gain*1000:.0f}g ({velocity_recent_g_day:.1f}g/ngày) và +{l_gain:.1f}cm trong {days_gap} ngày "
                    f"• Trung bình từ lúc sinh: {velocity_from_birth_g_day:.1f}g/ngày (Chuẩn vàng sơ sinh: 25 - 35g/ngày)"
                )

        return {
            "has_data": True,
            "latest_record": latest,
            "age_info": age_info,
            "gender": "Bé Trai" if gender_key == "boy" else "Bé Gái",
            "who_standards": {
                "month": months,
                "exact_months": exact_m,
                "total_days": total_days,
                "weight_median": w_med,
                "weight_range": f"{w_min} - {w_max} kg",
                "length_median": l_med,
                "length_range": f"{l_min} - {l_max} cm",
                "velocity_benchmark": "25 - 35 g/ngày (0 - 3 tháng đầu)",
                "citation": "Tiêu chuẩn Tăng trưởng Trẻ em của Tổ chức Y tế Thế giới (WHO Child Growth Standards - Nội suy theo ngày tuổi)"
            },
            "weight_status": w_status,
            "weight_color": w_color,
            "length_status": l_status,
            "length_color": l_color,
            "growth_velocity": growth_velocity,
            "velocity_from_birth_g_day": velocity_from_birth_g_day,
            "velocity_recent_g_day": velocity_recent_g_day,
            "history": self.records,
            "ai_analysis": self.get_latest_ai_analysis()
        }

    def save_ai_analysis(self, analysis: dict):
        """Lưu kết quả phân tích tăng trưởng và lời khuyên theo chuẩn WHO."""
        if not analysis:
            return
        ai_path = os.path.join(BASE_DIR, "baby_growth_ai.json")
        try:
            with open(ai_path, "w", encoding="utf-8") as f:
                json.dump(analysis, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[GrowthTracker] Lỗi lưu baby_growth_ai.json: {e}")

    def generate_instant_ai_summary(self, birth_date_str: str = "2026-09-29", gender: str = "boy", baby_name: str = "Bé") -> dict:
        """Tự động sinh nhận định lâm sàng chuẩn WHO tức thì theo số đo mới nhất của bé."""
        latest = self.get_latest_record()
        if not latest:
            return self.get_latest_ai_analysis()

        w = float(latest.get("weight_kg", 3.5))
        h = float(latest.get("height_cm", 52.0))
        curr_date = latest.get("date", date.today().strftime("%Y-%m-%d"))

        prev_rec = None
        if len(self.records) >= 2:
            prev_rec = self.records[-2]

        days_gap = 15
        w_diff_g = 0
        h_diff_cm = 0.0
        g_per_day = 0.0
        velocity_str = f"Số đo ghi nhận ngày {curr_date}: {w} kg, {h} cm"

        if prev_rec:
            try:
                d_c = parse_date(curr_date) or date.today()
                d_p = parse_date(prev_rec.get("date")) or (d_c - timedelta(days=15))
                days_gap = max(1, (d_c - d_p).days)
                p_w = float(prev_rec.get("weight_kg", w))
                p_h = float(prev_rec.get("height_cm", h))
                w_diff_g = round((w - p_w) * 1000)
                h_diff_cm = round(h - p_h, 1)
                g_per_day = round(w_diff_g / max(1, days_gap), 1)
                velocity_str = f"+{w_diff_g}g ({g_per_day}g/ngày), +{h_diff_cm}cm trong {days_gap} ngày"
            except Exception:
                pass

        d_curr_obj = parse_date(curr_date) or date.today()
        age_info = calculate_exact_age(birth_date_str, target_date=d_curr_obj)
        total_days = age_info["total_days"]
        months = min(12, age_info["full_months"])
        gender_key = "girl" if str(gender).lower() in ("girl", "gái", "female", "f") else "boy"
        w_med, w_min, w_max, l_med, l_min, l_max, _ = interpolate_who_standard(gender_key, total_days)

        vel_birth_g_day = 0.0
        if len(self.records) >= 1:
            birth_rec = self.records[0]
            d_b = parse_date(birth_rec.get("date")) or parse_date(birth_date_str)
            if d_b and (d_curr_obj - d_b).days > 0:
                vel_birth_g_day = round(((w - float(birth_rec.get("weight_kg", w))) * 1000.0) / (d_curr_obj - d_b).days, 1)
                if vel_birth_g_day > 0:
                    velocity_str = f"{velocity_str} | Trung bình từ lúc sinh: {vel_birth_g_day}g/ngày (Chuẩn vàng: 25-35g/ngày)"

        if w < w_min:
            status_badge = "⚠️ Cần theo dõi thêm (Dưới dải an toàn WHO)"
            w_comment = f"Cân nặng hiện tại {w} kg tiệm cận ngưỡng dưới so với trung vị WHO ({w_med} kg). Dải tiêu chuẩn khuyến nghị an toàn của WHO cho độ tuổi này là từ {w_min} đến {w_max} kg."
        elif w > w_max:
            status_badge = "🌟 Phát triển vượt trội so với chuẩn WHO"
            w_comment = f"Cân nặng hiện tại {w} kg phát triển vượt mức trung vị WHO ({w_med} kg). Dải tiêu chuẩn an toàn của WHO cho độ tuổi này là từ {w_min} đến {w_max} kg."
        else:
            status_badge = "✅ Nằm Trong Ngưỡng An Toàn WHO"
            w_comment = f"Cân nặng {w} kg và chiều cao {h} cm nằm trọn vẹn trong vùng an toàn theo Tiêu chuẩn Tăng trưởng Trẻ em của Tổ chức Y tế Thế giới (WHO: {w_min} - {w_max} kg, chiều dài {l_min} - {l_max} cm, mức trung vị {w_med} kg). Thể trạng của bé hoàn toàn an toàn và đạt chuẩn quốc tế."

        milk_need = int(w * 150)
        analysis = {
            "analyzed_at": datetime.now().strftime("%H:%M - %d/%m/%Y"),
            "days_gap": days_gap,
            "weight_gain_g": w_diff_g,
            "height_gain_cm": h_diff_cm,
            "velocity_str": velocity_str,
            "status_badge": status_badge,
            "velocity_evaluation_vi": f"{baby_name} hiện đạt cân nặng {w} kg và chiều cao {h} cm ({velocity_str}). Thể trạng của bé nằm trọn trong dải phát triển sinh lý an toàn theo quy chuẩn WHO, hấp thu dinh dưỡng tốt và tăng trưởng đều đặn.",
            "who_percentile_comparison_vi": w_comment,
            "recommendations_vi": [
                f"Duy trì tổng lượng sữa mẹ hoặc sữa công thức khoảng {milk_need} ml/ngày (140 - 160 ml/kg/ngày theo khuyến cáo dinh dưỡng Nhi khoa), chia đều các cữ bú.",
                "Tập cho bé nằm sấp có kiểm soát (Tummy Time) 3 - 5 phút mỗi ngày khi bé thức để rèn luyện cơ cổ và vai theo khuyến cáo AAP.",
                "Bổ sung đều đặn 400 IU Vitamin D3 mỗi buổi sáng để hỗ trợ hấp thu canxi và hoàn thiện khung xương."
            ],
            "doctor_quote_vi": f"Thể trạng của {baby_name} đang phát triển rất tốt trong ngưỡng an toàn chuẩn WHO. Ba mẹ hoàn toàn yên tâm duy trì cữ bú và nếp sinh hoạt đều đặn cho con nhé!",
            "model_used": "Chuẩn Tăng Trưởng Trẻ Em WHO (World Health Organization)"
        }
        self.save_ai_analysis(analysis)
        return analysis

    def get_latest_ai_analysis(self) -> dict:
        """Lấy kết quả phân tích tăng trưởng gần nhất theo chuẩn WHO."""
        ai_path = os.path.join(BASE_DIR, "baby_growth_ai.json")
        latest = self.get_latest_record()
        if os.path.exists(ai_path):
            try:
                with open(ai_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # Nếu file đã lưu khớp với số đo mới nhất thì trả về
                    if latest and str(latest.get("weight_kg", "")) in data.get("velocity_evaluation_vi", ""):
                        return data
            except Exception:
                pass
        
        # Nếu chưa khớp hoặc chưa có file, tự động sinh nhận định tức thì theo số đo mới nhất
        cfg_path = os.path.join(BASE_DIR, "config.json")
        b_name = "Bé A Siu"
        b_date = "2026-09-29"
        gender = "boy"
        if os.path.exists(cfg_path):
            try:
                with open(cfg_path, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                    b_name = cfg.get("baby_name", b_name)
                    b_date = cfg.get("baby_birth_date", b_date)
                    gender = cfg.get("baby_gender", gender)
            except Exception:
                pass
        return self.generate_instant_ai_summary(b_date, gender, b_name)
