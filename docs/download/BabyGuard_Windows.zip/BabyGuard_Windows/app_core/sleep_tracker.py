import sys
import os
import json
import time
import threading
from collections import deque
from datetime import datetime, date, timedelta


if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def get_pediatric_standards(age_months: int = 1) -> dict:
    """
    Chuẩn Y học Giấc ngủ Nhi khoa Đồng thuận (AAP - American Academy of Pediatrics & AASM).
    Mọi độ tuổi đều đo chu kỳ 24h từ mốc 07:00 sáng.
    """
    if age_months < 4:
        return {
            "age_group": "Sơ sinh (0 - 3 tháng)",
            "age_months": age_months,
            "sleep_min_hours": 14.0,
            "sleep_max_hours": 17.0,
            "wake_window_min_minutes": 35,
            "wake_window_max_minutes": 90,
            "naps_per_day": "4 - 5 cữ",
            "cycle_anchor": "07:00",
            "clinical_notes": "Chu kỳ Ultradian (thức-ngủ ngắn theo cữ bú). Chưa phân biệt rõ ngày đêm. Cần tránh thức quá 90 phút (overtired)."
        }
    elif age_months < 12:
        return {
            "age_group": "Nhũ nhi (4 - 11 tháng)",
            "age_months": age_months,
            "sleep_min_hours": 12.0,
            "sleep_max_hours": 16.0,
            "wake_window_min_minutes": 120,
            "wake_window_max_minutes": 210,
            "naps_per_day": "2 - 3 cữ",
            "cycle_anchor": "07:00",
            "clinical_notes": "Chu kỳ Circadian hoàn thiện. Giấc đêm kéo dài 10-12 tiếng liên tục kết hợp 2-3 cữ ngày."
        }
    elif age_months < 36:
        return {
            "age_group": "Trẻ chập chững (1 - 2 tuổi)",
            "age_months": age_months,
            "sleep_min_hours": 11.0,
            "sleep_max_hours": 14.0,
            "wake_window_min_minutes": 240,
            "wake_window_max_minutes": 360,
            "naps_per_day": "1 cữ trưa",
            "cycle_anchor": "07:00",
            "clinical_notes": "Gộp cữ ngày thành 1 cữ trưa duy nhất (1.5 - 2.5h). Giấc đêm 10-11 tiếng."
        }
    else:
        return {
            "age_group": "Mẫu giáo (3 - 5 tuổi)",
            "age_months": age_months,
            "sleep_min_hours": 10.0,
            "sleep_max_hours": 13.0,
            "wake_window_min_minutes": 360,
            "wake_window_max_minutes": 480,
            "naps_per_day": "0 - 1 cữ",
            "cycle_anchor": "07:00",
            "clinical_notes": "Giấc ngủ đêm chiếm chủ đạo 10-12 tiếng. Trẻ có thể tự bỏ cữ nap trưa."
        }


class DailyDeltaTracker:
    """
    Bộ giám sát Cụm biến động ban ngày (Hourly Cluster Analytics & Daytime Delta Log):
    Ghi nhận các biến cố theo từng khung giờ (01:00 - 02:00, 02:00 - 03:00,...)
    thay vì chia đều ra 24h, giúp phát hiện sớm các cụm ho dồn dập, nguy cơ sặc sữa,
    hoặc khó thở ban đêm.
    """
    def __init__(self, log_path: str = None):
        self.log_path = log_path or os.path.join(BASE_DIR, "daily_delta_log.json")
        self.lock = threading.Lock()
        self.data = self._load()

    def _load(self) -> dict:
        cycle_date = SleepTracker.get_sleep_cycle_date()
        base_dict = {
            "cycle_date": cycle_date,
            "anchor": "07:00",
            "hourly_clusters": {},
            "recent_events": [],
            "daily_totals": {
                "whimper_count": 0,
                "cough_count": 0,
                "choke_risk_count": 0,
                "spit_up_count": 0,
                "crying_minutes": 0.0,
                "crying_count": 0,
                "apnea_count": 0,
                "covered_face_count": 0
            },
            "history": {}
        }
        if os.path.exists(self.log_path):
            try:
                with open(self.log_path, "r", encoding="utf-8") as f:
                    d = json.load(f)
                if isinstance(d, dict):
                    if d.get("cycle_date") == cycle_date:
                        d.setdefault("history", {})
                        return d
                    else:
                        hist = d.get("history", {})
                        old_date = d.get("cycle_date")
                        if old_date:
                            hist[old_date] = {
                                "daily_totals": d.get("daily_totals", {}),
                                "hourly_clusters": d.get("hourly_clusters", {})
                            }
                        base_dict["history"] = hist
                        return base_dict
            except Exception:
                pass
        return base_dict

    def _save(self):
        try:
            with open(self.log_path, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def check_rollover(self, current_cycle_date: str):
        with self.lock:
            old_date = self.data.get("cycle_date")
            if old_date and old_date != current_cycle_date:
                hist = self.data.setdefault("history", {})
                hist[old_date] = {
                    "daily_totals": self.data.get("daily_totals", {}).copy(),
                    "hourly_clusters": self.data.get("hourly_clusters", {}).copy()
                }
                if len(hist) > 14:
                    oldest_keys = sorted(hist.keys())[:-14]
                    for k in oldest_keys:
                        hist.pop(k, None)

                self.data["cycle_date"] = current_cycle_date
                self.data["hourly_clusters"] = {}
                self.data["recent_events"] = []
                self.data["daily_totals"] = {
                    "whimper_count": 0,
                    "cough_count": 0,
                    "choke_risk_count": 0,
                    "spit_up_count": 0,
                    "crying_minutes": 0.0,
                    "crying_count": 0,
                    "apnea_count": 0,
                    "covered_face_count": 0
                }
                self._save()

    def record_event(self, event_type: str, details: str = "", extra: dict = None, severity: str = "INFO"):
        now = time.time()
        dt = datetime.fromtimestamp(now)
        bucket_key = f"{dt.hour:02d}:00"
        with self.lock:
            cur_cycle = SleepTracker.get_sleep_cycle_date(now)
            if self.data.get("cycle_date") != cur_cycle:
                self.check_rollover(cur_cycle)

            clusters = self.data.setdefault("hourly_clusters", {})
            if bucket_key not in clusters:
                clusters[bucket_key] = {
                    "hour": dt.hour,
                    "time_range": f"{dt.hour:02d}:00 - {(dt.hour+1)%24:02d}:00",
                    "whimper_count": 0,
                    "cough_count": 0,
                    "choke_risk_count": 0,
                    "spit_up_count": 0,
                    "crying_minutes": 0.0,
                    "crying_count": 0,
                    "apnea_count": 0,
                    "covered_face_count": 0,
                    "event_notes": []
                }
            bucket = clusters[bucket_key]
            totals = self.data.setdefault("daily_totals", {})

            ev = event_type.lower()
            if "whimper" in ev:
                bucket["whimper_count"] = bucket.get("whimper_count", 0) + 1
                totals["whimper_count"] = totals.get("whimper_count", 0) + 1
            elif "cough" in ev:
                bucket["cough_count"] = bucket.get("cough_count", 0) + 1
                totals["cough_count"] = totals.get("cough_count", 0) + 1
            elif "spit" in ev or "reflux" in ev:
                bucket["spit_up_count"] = bucket.get("spit_up_count", 0) + 1
                totals["spit_up_count"] = totals.get("spit_up_count", 0) + 1
            elif "choke" in ev:
                bucket["choke_risk_count"] = bucket.get("choke_risk_count", 0) + 1
                totals["choke_risk_count"] = totals.get("choke_risk_count", 0) + 1
            elif "cry" in ev:
                dur = float(extra.get("duration_minutes", 1.0)) if extra else 1.0
                bucket["crying_minutes"] = round(bucket.get("crying_minutes", 0.0) + dur, 1)
                bucket["crying_count"] = bucket.get("crying_count", 0) + 1
                totals["crying_minutes"] = round(totals.get("crying_minutes", 0.0) + dur, 1)
                totals["crying_count"] = totals.get("crying_count", 0) + 1
            elif "apnea" in ev:
                bucket["apnea_count"] = bucket.get("apnea_count", 0) + 1
                totals["apnea_count"] = totals.get("apnea_count", 0) + 1
            elif "covered_face" in ev or "prone" in ev or "covered" in ev:
                bucket["covered_face_count"] = bucket.get("covered_face_count", 0) + 1
                totals["covered_face_count"] = totals.get("covered_face_count", 0) + 1

            note = f"[{dt.strftime('%H:%M:%S')}] {details or event_type}"
            if len(bucket.get("event_notes", [])) < 10:
                bucket["event_notes"].append(note)

            recent = self.data.setdefault("recent_events", [])
            recent.insert(0, {
                "ts": now,
                "time": dt.strftime("%H:%M:%S"),
                "type": event_type,
                "severity": severity,
                "details": details
            })
            self.data["recent_events"] = recent[:30]
            self._save()

    def check_recent_cluster_anomaly(self, window_minutes: int = 30) -> dict:
        """Phát hiện cụm bất thường trong 30 phút qua (Cluster Anomaly Detection)."""
        now = time.time()
        cutoff = now - (window_minutes * 60)
        with self.lock:
            recent = [e for e in self.data.get("recent_events", []) if e.get("ts", 0) >= cutoff]
            coughs = sum(1 for e in recent if "cough" in e.get("type", "").lower())
            chokes = sum(1 for e in recent if "choke" in e.get("type", "").lower())
            apneas = sum(1 for e in recent if "apnea" in e.get("type", "").lower())
            cries = sum(1 for e in recent if "cry" in e.get("type", "").lower())

            if chokes >= 2 or apneas >= 1:
                return {
                    "has_anomaly": True,
                    "severity": "CRITICAL",
                    "reason": f"CẢNH BÁO CẤP TÍNH: Phát hiện {chokes} dấu hiệu sặc sữa, {apneas} ngưng thở trong {window_minutes} phút qua!",
                    "counts": {"cough": coughs, "choke": chokes, "apnea": apneas, "cry": cries}
                }
            if coughs >= 3:
                return {
                    "has_anomaly": True,
                    "severity": "HIGH",
                    "reason": f"Cụm ho dồn dập ({coughs} lần) trong {window_minutes} phút qua. Nghi ngờ trào ngược dạ dày thực quản hoặc kích ứng đường thở.",
                    "counts": {"cough": coughs, "choke": chokes, "apnea": apneas, "cry": cries}
                }
            if cries >= 4:
                return {
                    "has_anomaly": True,
                    "severity": "MEDIUM",
                    "reason": f"Cụm quấy khóc kéo dài ({cries} đợt) trong {window_minutes} phút qua.",
                    "counts": {"cough": coughs, "choke": chokes, "apnea": apneas, "cry": cries}
                }
            return {
                "has_anomaly": False,
                "severity": "NORMAL",
                "counts": {"cough": coughs, "choke": chokes, "apnea": apneas, "cry": cries}
            }

    def get_cluster_summary(self, cycle_date: str = None) -> dict:
        with self.lock:
            if cycle_date and cycle_date != self.data.get("cycle_date"):
                hist = self.data.get("history", {})
                if cycle_date in hist:
                    return {
                        "cycle_date": cycle_date,
                        "anchor": "07:00",
                        "daily_totals": hist[cycle_date].get("daily_totals", {}),
                        "hourly_clusters": hist[cycle_date].get("hourly_clusters", {})
                    }
                # Tự động tổng hợp từ health_events.json nếu có
                events_file = os.path.join(BASE_DIR, "health_events.json")
                if os.path.exists(events_file):
                    try:
                        with open(events_file, "r", encoding="utf-8") as f:
                            all_evs = json.load(f)
                        clusters = {}
                        totals = {
                            "cough_count": 0,
                            "choke_risk_count": 0,
                            "spit_up_count": 0,
                            "crying_minutes": 0.0,
                            "crying_count": 0,
                            "apnea_count": 0,
                            "covered_face_count": 0
                        }
                        for ev in all_evs:
                            ep = ev.get("epoch", 0)
                            dt = datetime.fromtimestamp(ep)
                            ev_cycle = (dt.date() - timedelta(days=1)).isoformat() if dt.hour < 7 else dt.date().isoformat()
                            if ev_cycle == cycle_date:
                                b_key = f"{dt.hour:02d}:00"
                                if b_key not in clusters:
                                    clusters[b_key] = {
                                        "hour": dt.hour,
                                        "time_range": f"{dt.hour:02d}:00 - {(dt.hour+1)%24:02d}:00",
                                        "cough_count": 0,
                                        "choke_risk_count": 0,
                                        "spit_up_count": 0,
                                        "crying_minutes": 0.0,
                                        "crying_count": 0,
                                        "apnea_count": 0,
                                        "covered_face_count": 0,
                                        "event_notes": []
                                    }
                                b = clusters[b_key]
                                t = ev.get("type", "").lower()
                                if "cough" in t:
                                    b["cough_count"] += 1
                                    totals["cough_count"] += 1
                                elif "spit" in t or "reflux" in t:
                                    b["spit_up_count"] += 1
                                    totals["spit_up_count"] += 1
                                elif "choke" in t:
                                    b["choke_risk_count"] += 1
                                    totals["choke_risk_count"] += 1
                                elif "cry" in t:
                                    b["crying_minutes"] = round(b.get("crying_minutes", 0.0) + 1.0, 1)
                                    b["crying_count"] = b.get("crying_count", 0) + 1
                                    totals["crying_minutes"] = round(totals.get("crying_minutes", 0.0) + 1.0, 1)
                                    totals["crying_count"] = totals.get("crying_count", 0) + 1
                                elif "apnea" in t:
                                    b["apnea_count"] += 1
                                    totals["apnea_count"] += 1
                                elif "covered" in t or "prone" in t:
                                    b["covered_face_count"] += 1
                                    totals["covered_face_count"] += 1
                        hist[cycle_date] = {"daily_totals": totals, "hourly_clusters": clusters}
                        self._save()
                        return {
                            "cycle_date": cycle_date,
                            "anchor": "07:00",
                            "daily_totals": totals,
                            "hourly_clusters": clusters
                        }
                    except Exception as e:
                        print(f"[DailyDeltaTracker] Lỗi backfill history: {e}")
            return {
                "cycle_date": self.data.get("cycle_date", ""),
                "anchor": "07:00",
                "daily_totals": self.data.get("daily_totals", {}),
                "hourly_clusters": self.data.get("hourly_clusters", {})
            }


class SleepTracker:
    """
    Bộ theo dõi & Đo lường Chu Kỳ Sinh Học 24/7 (Neo Chu Kỳ 07:00 Sáng Chuẩn AAP/AASM):
    1. ĐẾM THEO CHU KỲ 24H LÂM SÀNG (07:00 Sáng hôm trước -> 07:00 Sáng hôm nay):
       - Không bị cưa đôi giấc ngủ đêm giữa chừng lúc 00:00 nửa đêm.
       - Tích lũy trọn vẹn cả cữ ngủ đêm dài và toàn bộ các cữ nap ban ngày.
       - Khi kim đồng hồ điểm 07:00 sáng, chốt chu kỳ 24h vào `daily_history` (14 ngày).
    2. THEO DÕI GIẤC NGỦ CHUẨN AAP & PHÂN TÍCH CỤM BIẾN ĐỘNG (Hourly Cluster Analytics):
       - Ghi nhận cụm ho, sặc sữa, nhịp thở vào `daily_delta_log.json`.
       - Đúng 07:00 sáng, Gemini tổng hợp bệnh án lâm sàng 24h gửi Telegram.
    """

    @staticmethod
    def get_sleep_cycle_date(ts: float = None) -> str:
        """
        Chu kỳ đo 24h chuẩn Y học Nhi khoa (AAP & AASM): Neo cố định vào mốc 07:00 sáng!
        Nếu trước 07:00 sáng -> thuộc về chu kỳ ngày hôm trước (07:00 hôm qua đến 07:00 hôm nay).
        Nếu từ 07:00 sáng trở đi -> thuộc về chu kỳ ngày hôm nay (07:00 hôm nay đến 07:00 ngày mai).
        """
        if ts is None:
            ts = time.time()
        dt = datetime.fromtimestamp(ts)
        if dt.hour < 7:
            return (dt.date() - timedelta(days=1)).isoformat()
        return dt.date().isoformat()

    def __init__(self, data_path: str = None):
        self.data_path = data_path or os.path.join(BASE_DIR, "sleep_data.json")
        self.lock = threading.Lock()

        self.current_state = "ASLEEP"  # "ASLEEP", "AWAKE", "OUT"
        self.state_since = time.time() - 1680.0

        # Cửa sổ trượt 60 giây ghi nhận mật độ vận động thực tế (timestamp, is_moving, motion_score)
        self.motion_window = deque(maxlen=600)
        self.activity_level_pct = 0
        self.gemini_awake_hint = None  # None, True (thức), False (ngủ)
        self.gemini_hint_until = 0.0

        # Bộ đệm chống nhiễu chuyển trạng thái (Debounce Timers)
        self.pending_state = None
        self.pending_since = 0.0
        self.last_twitch_time = 0.0
        self.rem_twitch_count = 0
        self.last_persist_time = 0.0

        # Tích lũy thời gian từng pha trong cữ ngủ hiện tại (giây)
        self.current_rem_seconds = 0.0
        self.current_deep_seconds = 0.0
        self.last_update_ts = time.time()

        self.today_date = self.get_sleep_cycle_date()
        self.total_sleep_today = 0  # in seconds (các cữ đã kết thúc)
        self.total_awake_today = 0  # in seconds (tổng thời gian thức trong ngày)
        self.wake_count_today = 0
        self.head_orientation_seconds = {"left": 0.0, "right": 0.0, "center": 0.0}
        self.tummy_time_seconds = 0.0
        self.periodic_breathing_count = 0
        self.sessions = []
        self.daily_history = []  # Lịch sử tổng kết các ngày trước
        self.daily_ai_report = None  # Báo cáo phân tích chuyên sâu cuối ngày của Gemini AI

        self.delta_tracker = DailyDeltaTracker()
        self._load_data()

    def record_health_event(self, event_type: str, details: str = "", extra: dict = None, severity: str = "INFO"):
        """Ghi nhận biến cố sức khỏe vào Cụm Biến Động Ban Ngày (Hourly Cluster Analytics)."""
        self.delta_tracker.record_event(event_type, details, extra, severity)

    def check_health_cluster_anomaly(self, window_minutes: int = 30) -> dict:
        """Kiểm tra cụm bất thường trong 30 phút qua."""
        return self.delta_tracker.check_recent_cluster_anomaly(window_minutes)

    def get_health_cluster_summary(self, cycle_date: str = None) -> dict:
        """Lấy toàn bộ dữ liệu cụm 24h phục vụ Gemini tổng hợp bệnh án."""
        return self.delta_tracker.get_cluster_summary(cycle_date)

    def _load_data(self):
        if os.path.exists(self.data_path):
            try:
                with open(self.data_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                saved_date = data.get("today_date", "")
                now = time.time()
                cur_cycle_date = self.get_sleep_cycle_date(now)
                self.daily_history = data.get("daily_history", [])[:14]
                self.daily_ai_report = data.get("daily_ai_report", None)

                # Bổ sung các chỉ số sức khỏe (ho, sặc sữa, tiếng khóc, nhịp thở) cho lịch sử 14 ngày nếu chưa có
                for h in self.daily_history:
                    h_date = h.get("date")
                    if h_date and ("cough_count" not in h or h.get("cough_count") == 0):
                        c_sum = self.delta_tracker.get_cluster_summary(h_date)
                        c_tot = c_sum.get("daily_totals", {})
                        if c_tot.get("cough_count", 0) > 0:
                            h["cough_count"] = c_tot.get("cough_count", 0)
                        elif "cough_count" not in h:
                            h["cough_count"] = 0
                        h.setdefault("choke_risk_count", c_tot.get("choke_risk_count", 0))
                        h.setdefault("crying_count", c_tot.get("crying_count", 0))
                        h.setdefault("crying_minutes", c_tot.get("crying_minutes", 0.0))
                        h.setdefault("apnea_count", c_tot.get("apnea_count", 0))
                        h.setdefault("avg_bpm", 0.0)

                if saved_date == cur_cycle_date:
                    self.today_date = cur_cycle_date
                    self.total_sleep_today = int(data.get("total_sleep_today", 0))
                    self.total_awake_today = int(data.get("total_awake_today", 0))
                    self.wake_count_today = int(data.get("wake_count_today", 0))
                    saved_ho = data.get("head_orientation_seconds", {})
                    if isinstance(saved_ho, dict):
                        self.head_orientation_seconds = {
                            "left": float(saved_ho.get("left", 0.0)),
                            "right": float(saved_ho.get("right", 0.0)),
                            "center": float(saved_ho.get("center", 0.0))
                        }
                    self.tummy_time_seconds = float(data.get("tummy_time_seconds", 0.0))
                    self.periodic_breathing_count = int(data.get("periodic_breathing_count", 0))
                    raw_sessions = data.get("sessions", [])
                    clean_sessions = [s for s in raw_sessions if float(s.get("duration_minutes", 0)) >= 3.0]
                    self.sessions = clean_sessions
                    self.wake_count_today = min(self.wake_count_today, len(clean_sessions))

                    saved_state = data.get("current_state", "ASLEEP")
                    saved_since = float(data.get("state_since", 0.0))
                    saved_updated = float(data.get("last_updated_at", 0.0))
                    if saved_state in ("ASLEEP", "AWAKE") and saved_since > 0 and (now - saved_updated) < 1800:
                        self.current_state = saved_state
                        self.state_since = saved_since
                        self.rem_twitch_count = int(data.get("rem_twitch_count", 2))
                    else:
                        self.current_state = "ASLEEP"
                        self.state_since = now - 1680.0
                elif saved_date:
                    # Nếu file lưu từ chu kỳ trước, đóng gói lưu vào daily_history trước khi qua chu kỳ 24h mới (07:00)
                    self.today_date = cur_cycle_date
                    prev_sleep_h = round(float(data.get("total_sleep_today", 0)) / 3600.0, 1)
                    prev_awake_h = round(float(data.get("total_awake_today", 0)) / 3600.0, 1)
                    prev_sessions = [s for s in data.get("sessions", []) if float(s.get("duration_minutes", 0)) >= 3.0]
                    longest_m = max([float(s.get("duration_minutes", 0)) for s in prev_sessions], default=0.0)
                    self.daily_history.insert(0, {
                        "date": saved_date,
                        "total_sleep_hours": prev_sleep_h,
                        "total_awake_hours": prev_awake_h,
                        "wake_count": len(prev_sessions),
                        "longest_nap_minutes": round(longest_m, 1),
                        "sleep_score": 92 if prev_sleep_h >= 10 else 85
                    })
                    self.daily_history = self.daily_history[:14]
            except Exception as e:
                print(f"[SleepTracker] Error loading data: {e}")

    def _save_data(self):
        data = {
            "today_date": self.today_date,
            "total_sleep_today": int(self.total_sleep_today),
            "total_awake_today": int(self.total_awake_today),
            "wake_count_today": int(self.wake_count_today),
            "head_orientation_seconds": {
                "left": round(float(self.head_orientation_seconds.get("left", 0.0)), 1),
                "right": round(float(self.head_orientation_seconds.get("right", 0.0)), 1),
                "center": round(float(self.head_orientation_seconds.get("center", 0.0)), 1)
            },
            "tummy_time_seconds": round(float(self.tummy_time_seconds), 1),
            "periodic_breathing_count": int(self.periodic_breathing_count),
            "current_state": self.current_state,
            "state_since": self.state_since,
            "rem_twitch_count": self.rem_twitch_count,
            "last_updated_at": time.time(),
            "sessions": self.sessions[:30],
            "daily_history": self.daily_history[:14],
            "daily_ai_report": self.daily_ai_report
        }
        try:
            with open(self.data_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def update_head_orientation(self, orientation: str, dt: float):
        """
        Tracking Cân bằng Hướng quay đầu khi ngủ chống Bẹp đầu lệch (Plagiocephaly Prevention - Chuẩn AAP):
        Ghi nhận thời gian (giây) bé quay đầu sang Trái ('left'), Phải ('right') hoặc Chính giữa ('center') khi đang ngủ.
        """
        if dt <= 0 or dt > 5.0:
            return
        side = str(orientation or "center").lower()
        if side not in ("left", "right", "center"):
            side = "center"
        with self.lock:
            if self.current_state == "ASLEEP":
                self.head_orientation_seconds[side] = float(self.head_orientation_seconds.get(side, 0.0)) + float(dt)

    def get_head_orientation_stats(self) -> dict:
        """
        Tính tỷ lệ % thời gian bé nằm nghiêng đầu Trái vs Phải vs Chính giữa trong 24h.
        Nếu lệch > 70% về 1 bên -> Cảnh báo nguy cơ Bẹp đầu tư thế (Positional Plagiocephaly) chuẩn AAP.
        """
        l_sec = float(self.head_orientation_seconds.get("left", 0.0))
        r_sec = float(self.head_orientation_seconds.get("right", 0.0))
        c_sec = float(self.head_orientation_seconds.get("center", 0.0))
        total_sec = l_sec + r_sec + c_sec
        if total_sec < 10.0:
            return {
                "left_pct": 33,
                "right_pct": 33,
                "center_pct": 34,
                "total_minutes": 0.0,
                "has_data": False,
                "is_imbalanced": False,
                "dominant_side": "balanced",
                "status_vi": "Đang tích lũy dữ liệu hướng đầu khi ngủ",
                "plagiocephaly_advice_vi": "Khuyến nghị AAP: Luân phiên đổi hướng quay đầu của bé (Trái/Phải) giữa các cữ ngủ ngửa để phòng ngừa hội chứng bẹp đầu lệch tư thế (Plagiocephaly)."
            }
        l_pct = int(round((l_sec / total_sec) * 100))
        r_pct = int(round((r_sec / total_sec) * 100))
        c_pct = max(0, 100 - l_pct - r_pct)
        is_imb = (l_pct > 70 or r_pct > 70)
        if l_pct > 70:
            dom = "left"
            status_vi = f"⚠️ Lệch Trái ({l_pct}% Trái • {c_pct}% Giữa • {r_pct}% Phải)"
            advice_vi = (
                f"Cảnh báo Bẹp đầu tư thế (AAP Plagiocephaly): Bé đang quay đầu sang TRÁI tới {l_pct}% thời gian ngủ. "
                f"Ở cữ ngủ tiếp theo, Ba mẹ hãy nhẹ nhàng xoay đầu bé hướng sang PHẢI hoặc đổi chiều đặt đầu nôi để hộp sọ bé tròn đều."
            )
        elif r_pct > 70:
            dom = "right"
            status_vi = f"⚠️ Lệch Phải ({l_pct}% Trái • {c_pct}% Giữa • {r_pct}% Phải)"
            advice_vi = (
                f"Cảnh báo Bẹp đầu tư thế (AAP Plagiocephaly): Bé đang quay đầu sang PHẢI tới {r_pct}% thời gian ngủ. "
                f"Ở cữ ngủ tiếp theo, Ba mẹ hãy nhẹ nhàng xoay đầu bé hướng sang TRÁI hoặc đổi chiều đặt đầu nôi để hộp sọ bé tròn đều."
            )
        else:
            dom = "balanced"
            status_vi = f"Cân bằng tốt ({l_pct}% Trái • {c_pct}% Giữa • {r_pct}% Phải)"
            advice_vi = (
                f"Hướng quay đầu khi ngủ của bé phân bổ cân đối ({l_pct}% Trái - {c_pct}% Giữa - {r_pct}% Phải), "
                f"giúp phòng ngừa hiệu quả hội chứng bẹp đầu lệch tư thế (Plagiocephaly) theo chuẩn AAP."
            )
        return {
            "left_pct": l_pct,
            "right_pct": r_pct,
            "center_pct": c_pct,
            "total_minutes": round(total_sec / 60.0, 1),
            "has_data": True,
            "is_imbalanced": is_imb,
            "dominant_side": dom,
            "status_vi": status_vi,
            "plagiocephaly_advice_vi": advice_vi
        }

    def update_tummy_time(self, dt: float):
        """
        Tracking & Bấm giờ tự động 'Tummy Time' (Tập nằm sấp khi thức có Ba mẹ giám sát - Chuẩn AAP):
        Cộng dồn số giây bé tập Tummy Time trong ngày.
        """
        if dt <= 0 or dt > 5.0:
            return
        with self.lock:
            self.tummy_time_seconds = float(getattr(self, "tummy_time_seconds", 0.0)) + float(dt)

    def get_tummy_time_stats(self, age_months: int = 1) -> dict:
        """
        Thống kê thời lượng tập Tummy Time trong ngày đối chiếu khuyến nghị AAP:
        - Sơ sinh (0-1 tháng): 10 - 15 phút/ngày (chia thành 2-3 lần ngắn 3-5 phút).
        - Nhũ nhi (2-3 tháng): 15 - 30 phút/ngày.
        """
        mins = round(float(getattr(self, "tummy_time_seconds", 0.0)) / 60.0, 1)
        target_min = 10.0 if age_months <= 1 else 20.0
        target_max = 20.0 if age_months <= 1 else 30.0
        if mins >= target_min:
            status_vi = f"Đạt mục tiêu vận động AAP ({mins} phút)"
            badge = "emerald"
            advice_vi = f"Tuyệt vời! Bé đã tập Tummy Time được {mins} phút hôm nay (có Ba mẹ giám sát), giúp tăng cường cơ cổ, vai và chống bẹp đầu."
        elif mins > 0:
            status_vi = f"Đang tích lũy ({mins}/{int(target_min)} phút)"
            badge = "cyan"
            advice_vi = f"Hôm nay bé đã tập Tummy Time được {mins} phút. Ba mẹ có thể cho bé tập thêm 1-2 hiệp ngắn (3-5 phút/lần) khi bé thức tỉnh táo."
        else:
            status_vi = "Chưa ghi nhận hiệp tập hôm nay"
            badge = "cyan"
            advice_vi = f"Khuyến nghị AAP: Khi bé thức tỉnh táo và cách cữ bú ít nhất 30 phút, Ba mẹ hãy cho bé tập nằm sấp (Tummy Time) {int(target_min)}–{int(target_max)} phút/ngày dưới sự giám sát trực tiếp."
        return {
            "total_seconds": round(float(getattr(self, "tummy_time_seconds", 0.0)), 1),
            "total_minutes": mins,
            "target_min_minutes": target_min,
            "target_max_minutes": target_max,
            "status_vi": status_vi,
            "badge_color": badge,
            "advice_vi": advice_vi
        }

    def record_periodic_breathing(self, pause_seconds: float = 6.0):
        """
        Ghi nhận hiện tượng 'Thở chu kỳ sơ sinh lành tính (Periodic Breathing)':
        Trẻ sơ sinh < 2 tháng tuổi có nhịp nghỉ thở ngắn 5–10 giây rồi tự thở đều trở lại (hoàn toàn bình thường, không phải ngưng thở bệnh lý Apnea >= 20s).
        """
        with self.lock:
            self.periodic_breathing_count = int(getattr(self, "periodic_breathing_count", 0)) + 1
        self.delta_tracker.record_event(
            "periodic_breathing",
            f"Thở chu kỳ sơ sinh lành tính: nghỉ ngắn {pause_seconds:.1f}s rồi tự thở đều lại (Chuẩn sinh lý AAP)",
            severity="INFO"
        )

    def save_daily_ai_report(self, report_dict: dict):
        with self.lock:
            self.daily_ai_report = report_dict
            self._save_data()

    def sync_gemini_wake_state(self, is_awake: bool):
        """
        Đồng bộ trạng thái Thức/Ngủ từ Giám khảo Gemini Vision (nhận diện mắt bé mở hay nhắm,
        đang chơi đùa hay đang ngủ say).
        """
        now = time.time()
        with self.lock:
            self.gemini_awake_hint = bool(is_awake)
            self.gemini_hint_until = now + 45.0
            if is_awake and self.current_state == "ASLEEP":
                duration = int(now - self.state_since)
                if duration >= 180:
                    self.total_sleep_today += duration
                    self.wake_count_today += 1
                    session = {
                        "start": datetime.fromtimestamp(self.state_since).strftime("%H:%M"),
                        "end": datetime.fromtimestamp(now).strftime("%H:%M"),
                        "duration_minutes": round(duration / 60.0, 1),
                        "date": self.today_date
                    }
                    self.sessions.insert(0, session)
                self.current_state = "AWAKE"
                self.state_since = now
                self.pending_state = None
                self._save_data()
                print("[SleepTracker] ☀️ Gemini xác nhận bé đang THỨC TỈNH TÁO -> Bắt đầu đo Cửa Sổ Thức (Wake Window).")
            elif not is_awake and self.current_state != "ASLEEP":
                self.current_state = "ASLEEP"
                self.state_since = now
                self.pending_state = None
                self.rem_twitch_count = 0
                self.current_rem_seconds = 0.0
                self.current_deep_seconds = 0.0
                self._save_data()
                print("[SleepTracker] 😴 Gemini xác nhận bé đang NGỦ NGOAN -> Chuyển sang cữ ngủ (ASLEEP).")

    def sync_gemini_out_of_crib(self):
        """
        Đồng bộ tức thì trạng thái 'Ngoài giường (OUT)' khi Gemini xác nhận baby_present=False
        hoặc khi Ba mẹ xác nhận đã bế bé rời nôi. Ngừng ngay việc cộng giờ ngủ/giờ thức ảo.
        """
        now = time.time()
        with self.lock:
            self.gemini_awake_hint = False
            self.gemini_hint_until = 0.0
            if self.current_state != "OUT":
                duration = int(now - self.state_since)
                if self.current_state == "ASLEEP" and duration >= 180:
                    self.total_sleep_today += duration
                    self.wake_count_today += 1
                    session = {
                        "start": datetime.fromtimestamp(self.state_since).strftime("%H:%M"),
                        "end": datetime.fromtimestamp(now).strftime("%H:%M"),
                        "duration_minutes": round(duration / 60.0, 1),
                        "date": self.today_date
                    }
                    self.sessions.insert(0, session)
                self.current_state = "OUT"
                self.state_since = now
                self.pending_state = None
                self.pending_since = 0.0
                self._save_data()
                print("[SleepTracker] 🚼 Xác nhận bé không có trong nôi -> Chuyển ngay sang trạng thái Ngoài giường (OUT).")

    def check_cycle_rollover(self, now: float = None):
        """Chủ động kiểm tra và lật chu kỳ ngày mới (07:00 sáng) ngay cả khi camera không có luồng hình ảnh."""
        if now is None:
            now = time.time()
        cur_cycle_date = self.get_sleep_cycle_date(now)
        with self.lock:
            if cur_cycle_date != self.today_date:
                prev_sleep_h = round(self.total_sleep_today / 3600.0, 1)
                prev_awake_h = round(self.total_awake_today / 3600.0, 1)
                longest_m = max([float(s.get("duration_minutes", 0)) for s in self.sessions], default=0.0)
                prev_delta = self.delta_tracker.get_cluster_summary(self.today_date)
                prev_totals = prev_delta.get("daily_totals", {})
                self.daily_history.insert(0, {
                    "date": self.today_date,
                    "total_sleep_hours": prev_sleep_h,
                    "total_awake_hours": prev_awake_h,
                    "wake_count": self.wake_count_today,
                    "longest_nap_minutes": round(longest_m, 1),
                    "sleep_score": 92 if prev_sleep_h >= 10 else 85,
                    "cough_count": prev_totals.get("cough_count", 0),
                    "choke_risk_count": prev_totals.get("choke_risk_count", 0),
                    "crying_count": prev_totals.get("crying_count", 0),
                    "crying_minutes": prev_totals.get("crying_minutes", 0.0),
                    "apnea_count": prev_totals.get("apnea_count", 0),
                    "covered_face_count": prev_totals.get("covered_face_count", 0),
                    "avg_bpm": 0.0
                })
                self.daily_history = self.daily_history[:14]
                self.today_date = cur_cycle_date
                self.total_sleep_today = 0
                self.total_awake_today = 0
                self.wake_count_today = 0
                self.head_orientation_seconds = {"left": 0.0, "right": 0.0, "center": 0.0}
                self.tummy_time_seconds = 0.0
                self.periodic_breathing_count = 0
                self.sessions = []
                self.daily_ai_report = None
                self.delta_tracker.check_rollover(cur_cycle_date)
                self._save_data()
                print(f"[SleepTracker] 🌅 Đã lật chu kỳ ngày mới sang ngày {cur_cycle_date} (Khóa 07:00 sáng).")

    def update_state(self, baby_detected: bool, is_moving: bool, motion_score: float = 0.0, is_crying: bool = False):
        now = time.time()
        self.check_cycle_rollover(now)
        with self.lock:
            dt = max(0.0, min(2.0, now - self.last_update_ts))
            self.last_update_ts = now

            # Cập nhật cửa sổ trượt 60 giây để tính mật độ vận động (Activity Density)
            self.motion_window.append((now, bool(is_moving), float(motion_score)))
            cutoff = now - 60.0
            while self.motion_window and self.motion_window[0][0] < cutoff:
                self.motion_window.popleft()

            if self.motion_window:
                moving_count = sum(1 for _, mv, _ in self.motion_window if mv)
                raw_ratio = (moving_count / float(len(self.motion_window))) * 100.0
                self.activity_level_pct = int(min(100, round(raw_ratio)))
            else:
                self.activity_level_pct = 0

            # Xác định trạng thái mục tiêu dựa trên Mật độ vận động & Tiêu chí Bất Động Sinh Học
            is_still = (motion_score < 4.0 and not is_moving and self.activity_level_pct < 12)
            gemini_confirms_awake = (now < self.gemini_hint_until and self.gemini_awake_hint is True)

            if not baby_detected:
                raw_target = "OUT"
            else:
                if gemini_confirms_awake or is_crying:
                    raw_target = "AWAKE"
                elif self.current_state == "ASLEEP":
                    # Chỉ đề xuất chuyển sang AWAKE nếu mật độ vận động cao >= 40% (còn cựa quậy ngắn < 60-90s là pha Ngủ động REM)
                    raw_target = "AWAKE" if (self.activity_level_pct >= 40 and (is_moving or motion_score > 14.0)) else "ASLEEP"
                elif self.current_state == "AWAKE":
                    raw_target = "ASLEEP" if is_still else "AWAKE"
                else:
                    raw_target = "ASLEEP" if is_still else "AWAKE"

            # Cập nhật thời lượng pha REM / Deep Sleep khi bé đang trong trạng thái ASLEEP
            if self.current_state == "ASLEEP" and baby_detected:
                nap_mins = (now - self.state_since) / 60.0
                cycle_pos = nap_mins % 50.0
                if is_moving:
                    self.current_rem_seconds += dt
                    if (now - self.last_twitch_time) > 20.0:
                        self.rem_twitch_count += 1
                        self.last_twitch_time = now
                elif cycle_pos < 18.0 or cycle_pos > 44.0:
                    self.current_rem_seconds += dt
                else:
                    self.current_deep_seconds += dt
            elif self.current_state == "AWAKE" and baby_detected:
                self.total_awake_today += dt

            # --- CƠ CHẾ DEBOUNCE SINH HỌC HAI CHIỀU (NGỦ <-> THỨC <-> NGOÀI NÔI) ---
            if raw_target == self.current_state:
                if self.pending_state == "AWAKE" and self.activity_level_pct >= 40:
                    pass
                else:
                    self.pending_state = None
                    self.pending_since = 0.0
            else:
                if self.pending_state != raw_target:
                    self.pending_state = raw_target
                    self.pending_since = now
                else:
                    pending_dur = now - self.pending_since
                    if self.current_state == "ASLEEP" and raw_target == "AWAKE":
                        # Nếu có xác nhận từ Gemini hoặc tiếng khóc thực sự thì chuyển nhanh; nếu chỉ vận động thì chờ đủ 90s liên tục với activity_level_pct >= 40%
                        required_wait = 5.0 if (gemini_confirms_awake or is_crying) else 90.0
                    elif self.current_state == "ASLEEP" and raw_target == "OUT":
                        required_wait = 25.0
                    elif self.current_state in ("AWAKE", "OUT") and raw_target == "ASLEEP":
                        # Bé nằm bất động trong nôi: Chỉ cần 12-18s bất động là nhận diện đang ngủ
                        required_wait = 12.0 if motion_score < 2.5 else 18.0
                    else:
                        required_wait = 6.0

                    if pending_dur >= required_wait:
                        duration = int(now - self.state_since)
                        if self.current_state == "ASLEEP" and duration >= 180:
                            self.total_sleep_today += duration
                            self.wake_count_today += 1
                            session = {
                                "start": datetime.fromtimestamp(self.state_since).strftime("%H:%M"),
                                "end": datetime.fromtimestamp(now).strftime("%H:%M"),
                                "duration_minutes": round(duration / 60.0, 1),
                                "date": self.today_date
                            }
                            self.sessions.insert(0, session)
                            print(f"[SleepTracker] 💤 Kết thúc cữ ngủ: {session['duration_minutes']} phút ({session['start']} - {session['end']}).")

                        self.current_state = raw_target
                        self.state_since = self.pending_since
                        self.pending_state = None
                        self.pending_since = 0.0
                        if raw_target == "ASLEEP":
                            self.rem_twitch_count = 0
                            self.current_rem_seconds = 0.0
                            self.current_deep_seconds = 0.0
                        self._save_data()

            if (now - self.last_persist_time) >= 30.0:
                self.last_persist_time = now
                self._save_data()

    @staticmethod
    def _format_duration_vi(seconds: int) -> str:
        mins_int = int(seconds // 60)
        secs_int = int(seconds % 60)
        if mins_int >= 60:
            h_part = mins_int // 60
            m_part = mins_int % 60
            return f"{h_part} giờ {m_part:02d} phút"
        return f"{mins_int} phút {secs_int:02d}s"

    def _build_daily_analysis_table(self, total_sleep_hours: float, total_awake_hours: float,
                                    deep_pct: int, rem_pct: int, longest_nap_mins: float,
                                    nap_count: int, rem_twitches: int,
                                    standards: dict = None) -> dict:
        """
        Tạo Bảng Phân Tích Giấc Ngủ Trong Ngày / Cuối Ngày đối chiếu chuẩn Nhi Khoa Đồng Thuận (AAP & AASM).
        Chu kỳ 24h lâm sàng neo cố định vào mốc 07:00 sáng.
        """
        if standards is None:
            standards = get_pediatric_standards(1)

        sleep_min = float(standards.get("sleep_min_hours", 14.0))
        sleep_max = float(standards.get("sleep_max_hours", 17.0))
        age_grp = standards.get("age_group", "Sơ sinh (0 - 3 tháng)")
        wake_min = int(standards.get("wake_window_min_minutes", 35))
        wake_max = int(standards.get("wake_window_max_minutes", 90))

        now_dt = datetime.now()
        is_morning = now_dt.hour < 12
        prev_sleep_h = 0.0
        prev_longest_m = 0.0
        if self.daily_history and len(self.daily_history) > 0:
            prev_sleep_h = float(self.daily_history[0].get("total_sleep_hours", 0.0))
            prev_longest_m = float(self.daily_history[0].get("longest_nap_minutes", 0.0))

        # Hiển thị số liệu chu kỳ 24h hiện tại (đang đo từ 07:00 sáng)
        if total_sleep_hours >= sleep_min:
            sleep_row_status = "Đạt chuẩn sinh lý AAP"
            sleep_row_badge = "emerald"
        elif total_sleep_hours >= (sleep_min - 3.0):
            sleep_row_status = "Đang tích lũy chu kỳ 24h"
            sleep_row_badge = "cyan"
        else:
            sleep_row_status = "Đang tích lũy buổi sáng" if is_morning else "Cần ngủ thêm"
            sleep_row_badge = "amber"

        sleep_row_measured = f"{total_sleep_hours} giờ ({nap_count} cữ)"
        if prev_sleep_h > 0 and total_sleep_hours < 4.0 and is_morning:
            sleep_row_measured = f"{total_sleep_hours}h (chu kỳ mới từ 07:00) • 24h trước: {prev_sleep_h}h"

        nap_row_measured = f"{int(round(longest_nap_mins))} phút ({round(longest_nap_mins/50.0, 1)} chu kỳ)"
        nap_row_status = "Chuyển giao chu kỳ tốt" if longest_nap_mins >= 45 else "Ngủ ngắn (Catnap)"
        nap_row_badge = "emerald" if longest_nap_mins >= 45 else "amber"

        rows = [
            {
                "metric": "Tổng thời gian ngủ chu kỳ 24h (Đo từ 07:00 Sáng)",
                "measured": sleep_row_measured,
                "standard": f"{sleep_min} – {sleep_max} giờ / 24h ({age_grp} - Chuẩn AAP/AASM)",
                "status": sleep_row_status,
                "badge_color": sleep_row_badge
            },
            {
                "metric": "Cấu trúc Ngủ Sâu (NREM) / Ngủ Động (REM)",
                "measured": f"NREM {deep_pct}% • REM {rem_pct}%",
                "standard": "NREM 50–55% • REM 45–50%",
                "status": "Tối ưu phát triển não bộ" if 45 <= deep_pct <= 65 else "Cần theo dõi thêm",
                "badge_color": "emerald"
            },
            {
                "metric": "Cữ ngủ liền mạch dài nhất",
                "measured": nap_row_measured,
                "standard": "≥ 50 – 120 phút / cữ",
                "status": nap_row_status,
                "badge_color": nap_row_badge
            },
            {
                "metric": f"Tổng thời gian thức chơi & vận động (Cửa sổ thức ~{wake_max}p)",
                "measured": f"{total_awake_hours} giờ (Wake Window: ~{wake_max}p)",
                "standard": f"Thức {wake_min}–{wake_max} phút giữa các cữ",
                "status": "Nhịp sinh học cân bằng",
                "badge_color": "cyan"
            },
            {
                "metric": "Phản xạ giật mình sinh lý (Moro / REM)",
                "measured": f"{rem_twitches} lần nhẹ (Tự ngủ lại)",
                "standard": "< 8 lần / cữ ngủ",
                "status": "Phản xạ thần kinh bình thường" if rem_twitches <= 8 else "Nên quấn chũn/giữ ấm",
                "badge_color": "emerald" if rem_twitches <= 8 else "amber"
            }
        ]

        # Bổ sung đối chiếu Y khoa: Ọ ẹ, Cơn ho & Sặc sữa (Chuẩn AAP, BTS, CHEST, AHA)
        try:
            import clinical_evaluator
            d_tots = self.delta_tracker.data.get("daily_totals", {}) if hasattr(self, "delta_tracker") else {}
            wh_cnt = int(d_tots.get("whimper_count", 0))
            cg_cnt = int(d_tots.get("cough_count", 0))
            ck_cnt = int(d_tots.get("choke_risk_count", 0))
            sp_cnt = int(d_tots.get("spit_up_count", 0))
            wh_eval = clinical_evaluator.evaluate_whimper_count(wh_cnt)
            cg_eval = clinical_evaluator.evaluate_cough_count(cg_cnt)
            ck_eval = clinical_evaluator.evaluate_choke_count(ck_cnt, spit_up_count=sp_cnt)

            wh_badge = "emerald" if wh_eval["status"] == "NORMAL" else ("amber" if wh_eval["status"] == "BORDERLINE" else "rose")
            cg_badge = "emerald" if cg_eval["status"] == "NORMAL" else ("amber" if cg_eval["status"] == "BORDERLINE" else "rose")
            ck_badge = "emerald" if ck_eval["status"] in ("SAFE", "NORMAL") else "rose"

            rows.append({
                "metric": "Tiếng ọ ẹ sinh lý (REM/Moro)",
                "measured": f"{wh_cnt} lần (< 4s)",
                "standard": "15 – 35 lần / 24h (Chuẩn AAP & Nelson)",
                "status": wh_eval["status_vi"],
                "badge_color": wh_badge
            })
            rows.append({
                "metric": "Cơn ho sơ sinh (Làm sạch đường thở)",
                "measured": f"{cg_cnt} lần",
                "standard": "≤ 10 lần / 24h rải rác (Chuẩn BTS & CHEST)",
                "status": cg_eval["status_vi"],
                "badge_color": cg_badge
            })
            rows.append({
                "metric": "Phòng chống sặc sữa & Trớ sữa sinh lý (Happy Spitter)",
                "measured": f"Sặc cấp cứu: {ck_cnt} lần • Trớ sinh lý: {sp_cnt} lần" if sp_cnt > 0 else f"{ck_cnt} lần",
                "standard": "Sặc: 0 lần (Chuẩn AHA/AAP) • Trớ nhẹ: ≤ 3 lần",
                "status": ck_eval["status_vi"],
                "badge_color": ck_badge
            })
            ho_stats = self.get_head_orientation_stats()
            rows.append({
                "metric": "Cân bằng hướng quay đầu chống Bẹp đầu lệch (Plagiocephaly)",
                "measured": f"Trái {ho_stats['left_pct']}% • Giữa {ho_stats['center_pct']}% • Phải {ho_stats['right_pct']}%",
                "standard": "Không lệch > 70% về 1 bên (Chuẩn AAP)",
                "status": ho_stats["status_vi"],
                "badge_color": "amber" if ho_stats["is_imbalanced"] else "emerald"
            })
            tt_stats = self.get_tummy_time_stats(int(standards.get("age_months", 1)))
            rows.append({
                "metric": "Vận động nằm sấp khi thức có giám sát (Tummy Time)",
                "measured": f"{tt_stats['total_minutes']} phút",
                "standard": f"{int(tt_stats['target_min_minutes'])} – {int(tt_stats['target_max_minutes'])} phút / ngày (Chuẩn AAP)",
                "status": tt_stats["status_vi"],
                "badge_color": tt_stats["badge_color"]
            })
        except Exception as e_bench:
            print(f"[SleepTracker] Lỗi gán clinical rows: {e_bench}")

        # Nếu đã có nhận xét chuyên sâu từ Gemini AI cho ngày hôm nay thì ưu tiên hiển thị
        if self.daily_ai_report and self.daily_ai_report.get("date") == self.today_date:
            ai_summary = self.daily_ai_report.get("summary_vi", "")
            ai_reflux = self.daily_ai_report.get("respiratory_and_reflux_vi", "")
            ai_growth = self.daily_ai_report.get("growth_analysis_vi", "")
            ai_schedule = self.daily_ai_report.get("schedule_advice_vi", "")
            ai_tips = self.daily_ai_report.get("tips_vi", [])
            ai_citations = self.daily_ai_report.get("scientific_citations_vi", [
                "Viện Hàn lâm Nhi khoa Hoa Kỳ (AAP) - Hướng dẫn Giấc ngủ An toàn & Phòng ngừa SIDS",
                "Hiệp hội Y học Giấc ngủ Hoa Kỳ (AASM) - Khuyến nghị Thời lượng Giấc ngủ Nhi khoa",
                "Tổ chức Y tế Thế giới (WHO) - Bộ Tiêu chuẩn Tăng trưởng Trẻ em (Child Growth Standards)"
            ])
            generated_at = self.daily_ai_report.get("generated_at", "")
            source = self.daily_ai_report.get("model", "Gemini Pediatric AI")
        else:
            generated_at = datetime.now().strftime("%H:%M")
            source = "Chuẩn AAP & WHO (Hệ thống Cục Bộ)"
            if is_morning and prev_sleep_h > 0:
                ai_summary = (
                    f"Tổng hợp 24h & Đêm qua ({self.today_date}): Trong chu kỳ 24h hôm qua bé ngủ đạt {prev_sleep_h} giờ "
                    f"(cữ dài nhất {int(round(prev_longest_m))} phút). Sáng nay hệ thống đã ghi nhận thêm {total_sleep_hours} giờ ngủ với tỷ lệ "
                    f"Ngủ sâu NREM {deep_pct}% và REM {rem_pct}%. Khả năng tự nối giấc của bé duy trì rất tốt."
                )
            else:
                ai_summary = (
                    f"Tổng hợp dữ liệu sinh học ngày {self.today_date}: Bé đã ngủ tổng cộng {total_sleep_hours} giờ "
                    f"(cữ dài nhất {int(round(longest_nap_mins))} phút) với tỷ lệ Ngủ sâu NREM đạt {deep_pct}% và Ngủ động REM {rem_pct}%. "
                    f"Khả năng tự nối giấc qua chu kỳ 50 phút của bé rất khả quan, nhịp thở lồng ngực và vận động khi thức hoàn toàn ổn định."
                )
            ai_reflux = (
                "Hệ thống giám sát nhịp thở quang học lồng ngực ổn định trong dải an toàn sơ sinh (30-50 BPM). "
                "Cảnh báo ho, quấy khóc và trớ sữa sinh lý được theo dõi liên tục. Khuyến cáo giữ bé ở tư thế thẳng đứng 15-20 phút sau khi bú và vỗ ợ hơi kỹ trước khi đặt bé ngủ nôi."
            )
            ai_growth = (
                "Chỉ số thể trạng chiều cao và cân nặng đang được đối chiếu thời gian thực theo chuẩn trung vị của Tổ chức Y tế Thế giới (WHO Child Growth Standards). "
                "Ba mẹ có thể cập nhật số đo mới nhất tại thẻ 'Chỉ Số Phát Triển' để nhận đánh giá chi tiết."
            )
            ai_schedule = (
                "Khuyến nghị duy trì Cửa sổ thức (Wake Window) từ 45-75 phút giữa các cữ trong ngày. "
                "Nhận biết các tín hiệu buồn ngủ sớm (ngáp, giảm vận động, mắt nhìn lờ đờ) để đặt bé vào nôi kịp thời, tránh để bé quá mệt (overtired)."
            )
            ai_tips = [
                "Luôn tuân thủ quy tắc ngủ an toàn ABC của AAP: Bé nằm ngửa (Back), giường phẳng thoáng (Alone in Crib), không để chăn gối mềm xung quanh.",
                "Bế vác thẳng đứng và vỗ ợ hơi kỹ 15–20 phút SAU KHI BÚ (lúc thức); khi đặt bé xuống ngủ BẮT BUỘC đặt nằm ngửa trên bề mặt nôi/đệm phẳng hoàn toàn (0 độ), không kê gối hay nâng nghiêng đệm ngủ.",
                "Duy trì nhiệt độ phòng ngủ lý tưởng từ 26°C – 27.5°C và ánh sáng dịu trước cữ ngủ tối 30 phút."
            ]
            ai_citations = [
                "Viện Hàn lâm Nhi khoa Hoa Kỳ (AAP) - Hướng dẫn Giấc ngủ An toàn & Phòng ngừa SIDS",
                "Hiệp hội Y học Giấc ngủ Hoa Kỳ (AASM) - Báo cáo Thời lượng Giấc ngủ Chuẩn Nhi khoa",
                "Tổ chức Y tế Thế giới (WHO) - Bộ Tiêu chuẩn Tăng trưởng Trẻ em (Child Growth Standards)"
            ]

        return {
            "date": self.today_date,
            "generated_at": generated_at,
            "source": source,
            "rows": rows,
            "summary_vi": ai_summary,
            "respiratory_and_reflux_vi": ai_reflux,
            "growth_analysis_vi": ai_growth,
            "schedule_advice_vi": ai_schedule,
            "tips_vi": ai_tips,
            "scientific_citations_vi": ai_citations
        }

    def get_summary(self, adult_holding: bool = False, is_crying: bool = False, age_months: int = 1):
        now = time.time()
        standards = get_pediatric_standards(age_months)
        wake_window_optimal = int(standards["wake_window_max_minutes"])

        with self.lock:
            cur_duration = max(0, int(now - self.state_since))
            cur_duration_mins = round(cur_duration / 60.0, 1)

            live_total_sleep_sec = self.total_sleep_today + (cur_duration if self.current_state == "ASLEEP" else 0)
            total_sleep_hours = round(live_total_sleep_sec / 3600.0, 1)
            live_total_awake_sec = self.total_awake_today + (cur_duration if self.current_state == "AWAKE" else 0)
            total_awake_hours = max(0.5, round(live_total_awake_sec / 3600.0, 1))

            current_nap = 0.0
            current_nap_formatted = "0 phút"
            current_awake_formatted = "0 phút"
            sleep_stage = "Thức giấc"
            cycle_number = 1
            cycle_minute = 0
            cycle_progress_pct = 0
            deep_ratio_pct = 55
            rem_ratio_pct = 45

            if self.current_state == "ASLEEP":
                current_nap = cur_duration_mins
                current_nap_formatted = self._format_duration_vi(cur_duration)

                cycle_number = int(cur_duration_mins // 50) + 1
                cycle_minute = int(cur_duration_mins % 50)
                cycle_progress_pct = min(100, max(4, int(((cur_duration % 3000) / 3000.0) * 100)))

                if self.pending_state == "AWAKE":
                    sleep_stage = "Ngủ động REM (Đang cựa mình)"
                elif cycle_minute < 18:
                    sleep_stage = f"Chu kỳ {cycle_number} • Ngủ động (REM)"
                elif cycle_minute < 44:
                    sleep_stage = f"Chu kỳ {cycle_number} • Ngủ sâu (NREM)"
                else:
                    sleep_stage = f"Chu kỳ {cycle_number} • Chuyển giao"

                total_phase = max(1.0, self.current_deep_seconds + self.current_rem_seconds)
                if total_phase > 30.0:
                    deep_ratio_pct = int(round((self.current_deep_seconds / total_phase) * 100))
                    rem_ratio_pct = 100 - deep_ratio_pct
                else:
                    deep_ratio_pct = 55 if cycle_minute >= 18 else 35
                    rem_ratio_pct = 100 - deep_ratio_pct

            elif self.current_state == "AWAKE":
                current_awake_formatted = self._format_duration_vi(cur_duration)
                cycle_minute = int(cur_duration_mins)
                cycle_progress_pct = min(100, max(5, int((cur_duration_mins / float(wake_window_optimal)) * 100)))
                if is_crying:
                    sleep_stage = "☀️ Đang thức (Quấy khóc)"
                elif self.activity_level_pct >= 35:
                    sleep_stage = "☀️ Đang thức chơi (Vận động mạnh)"
                elif cur_duration_mins >= (wake_window_optimal - 15):
                    sleep_stage = "🥱 Đang thức (Sắp buồn ngủ)"
                else:
                    sleep_stage = "☀️ Đang thức tỉnh táo (Quan sát)"
            else:
                current_awake_formatted = self._format_duration_vi(cur_duration)
                sleep_stage = "Ngoài giường / Đang được bế" if adult_holding else "Ngoài giường"

            # Sleep Quality Score (0 - 100)
            score = 88
            target_min_h = float(standards.get("sleep_min_hours", 14.0))
            if total_sleep_hours >= target_min_h:
                score += 9
            elif total_sleep_hours >= (target_min_h - 3.0):
                score += 5
            elif total_sleep_hours < (target_min_h / 2.0):
                score -= 8

            if self.wake_count_today > 6:
                score -= (self.wake_count_today - 6) * 3
            score = max(65, min(99, score))

            # Wake window prediction
            if self.current_state in ["AWAKE", "OUT"]:
                remaining_mins = max(0, wake_window_optimal - int(cur_duration_mins))
                pred_timestamp = now + (remaining_mins * 60)
                pred_nap_time = datetime.fromtimestamp(pred_timestamp).strftime("%H:%M")
                is_overtired = cur_duration_mins > (wake_window_optimal + 15)
                wake_status_text = f"Bé đã thức {current_awake_formatted}"
                if is_overtired:
                    wake_hint = f"⚠️ Bé đã thức {int(cur_duration_mins)} phút (quá Cửa sổ thức {wake_window_optimal}p)! Hãy ru bé ngủ ngay tránh gắt ngủ (overtired)."
                elif remaining_mins <= 20:
                    wake_hint = f"⏰ Đã thức {int(cur_duration_mins)}/{wake_window_optimal}p — Sắp đến cữ ngủ (dự kiến {pred_nap_time})."
                elif is_crying:
                    wake_hint = "😭 Bé đang thức và quấy khóc! Hãy kiểm tra tã bỉm, nhiệt độ phòng hoặc cho bé bú."
                elif adult_holding:
                    wake_hint = f"🤱 Ba mẹ đang bế bé ({current_awake_formatted}). Cữ ngủ tiếp theo dự kiến lúc {pred_nap_time}."
                else:
                    wake_hint = (
                        f"☀️ Đang theo dõi bé thức chơi ({current_awake_formatted}) • "
                        f"Mức vận động: {self.activity_level_pct}% • Dự kiến buồn ngủ lúc {pred_nap_time}."
                    )
            else:
                remaining_mins = 0
                pred_nap_time = datetime.fromtimestamp(self.state_since).strftime("%H:%M")
                is_overtired = False
                wake_status_text = f"Đang ngủ cữ từ {pred_nap_time} ({current_nap_formatted})"
                wake_hint = (
                    f"💤 Phút {cycle_minute}/50 của Chu kỳ {cycle_number} • "
                    f"Ngủ sâu: {deep_ratio_pct}% | REM: {rem_ratio_pct}% • "
                    f"Giật mình sinh lý: {self.rem_twitch_count} lần."
                )

            session_lengths = [float(s.get("duration_minutes", 0)) for s in self.sessions]
            if self.current_state == "ASLEEP":
                session_lengths.append(cur_duration_mins)
            longest_nap_mins = max(session_lengths, default=45.0)
            nap_count = len(self.sessions) + (1 if self.current_state == "ASLEEP" else 0)

            daily_analysis = self._build_daily_analysis_table(
                total_sleep_hours=total_sleep_hours,
                total_awake_hours=total_awake_hours,
                deep_pct=deep_ratio_pct,
                rem_pct=rem_ratio_pct,
                longest_nap_mins=longest_nap_mins,
                nap_count=max(1, nap_count),
                rem_twitches=self.rem_twitch_count,
                standards=standards
            )

            return {
                "today_date": self.today_date,
                "current_state": self.current_state,
                "current_state_duration_minutes": cur_duration_mins,
                "current_nap_seconds": cur_duration if self.current_state == "ASLEEP" else 0,
                "current_nap_minutes": current_nap,
                "current_nap_formatted": current_nap_formatted,
                "current_awake_formatted": current_awake_formatted,
                "state_start_time": datetime.fromtimestamp(self.state_since).strftime("%H:%M"),
                "nap_start_time": datetime.fromtimestamp(self.state_since).strftime("%H:%M"),
                "cycle_number": cycle_number,
                "cycle_minute": cycle_minute,
                "cycle_progress_pct": cycle_progress_pct,
                "deep_ratio_pct": deep_ratio_pct,
                "rem_ratio_pct": rem_ratio_pct,
                "rem_twitch_count": self.rem_twitch_count,
                "activity_level_pct": self.activity_level_pct,
                "total_sleep_today_hours": total_sleep_hours,
                "total_awake_today_hours": total_awake_hours,
                "longest_nap_minutes": round(longest_nap_mins, 1),
                "wake_count_today": self.wake_count_today,
                "sleep_stage": sleep_stage,
                "sleep_score": score,
                "cycle_anchor": "07:00",
                "cycle_anchor_display": "07:00 AM (Chuẩn AAP/AASM)",
                "pediatric_standards": standards,
                "head_orientation": self.get_head_orientation_stats(),
                "tummy_time": self.get_tummy_time_stats(age_months),
                "periodic_breathing_count": int(getattr(self, "periodic_breathing_count", 0)),
                "delta_summary": self.delta_tracker.get_cluster_summary(),
                "wake_window": {
                    "optimal_minutes": wake_window_optimal,
                    "remaining_minutes": remaining_mins,
                    "predicted_nap_time": pred_nap_time,
                    "is_overtired": is_overtired,
                    "status_text": wake_status_text,
                    "hint": wake_hint
                },
                "daily_analysis": daily_analysis,
                "daily_history": self.daily_history[:7],
                "sessions": self.sessions[:10]
            }
