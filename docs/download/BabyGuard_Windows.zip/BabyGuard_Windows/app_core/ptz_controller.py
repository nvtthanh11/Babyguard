"""
PTZ Controller (ONVIF Profile S/T) cho BabyGuard AI.
- Tự động kiểm tra (Probe) xem camera đang kết nối có hỗ trợ xoay PTZ qua phần mềm không.
- Thực thi lệnh xoay Pan / Tilt (Trái, Phải, Lên, Xuống, Dừng, Về vị trí nôi Home).
- Hỗ trợ chế độ Auto-Tracking thông minh xoay theo vị trí em bé khi được bật.
"""
import re
import socket
import base64
import hashlib
import os
import time
import threading
from datetime import datetime, timezone
from urllib.parse import urlparse
import requests


class PTZController:
    def __init__(self, config: dict = None):
        self.config = config or {}
        self.lock = threading.Lock()
        self.supported = False
        self.camera_type = "usb"
        self.reason_vi = "Camera cố định / Webcam máy tính (Không có motor xoay PTZ)"
        self.host = ""
        self.port = 80
        self.username = ""
        self.password = ""
        self.ptz_service_url = ""
        self.profile_token = "Profile_1"
        self.auto_tracking_enabled = bool(self.config.get("ptz_auto_tracking", False))
        self.last_probe_time = 0.0
        self.last_track_move_time = 0.0
        self._stop_timer = None

    def update_config(self, cfg: dict):
        with self.lock:
            self.config.update(cfg)
            self.auto_tracking_enabled = bool(self.config.get("ptz_auto_tracking", False))

    @staticmethod
    def _parse_rtsp_url(rtsp_url: str) -> dict:
        if not rtsp_url or not isinstance(rtsp_url, str):
            return {}
        url_str = rtsp_url.strip()
        if not url_str.lower().startswith(("rtsp://", "http://", "https://")):
            return {}
        try:
            parsed = urlparse(url_str)
            return {
                "host": parsed.hostname or "",
                "rtsp_port": parsed.port or 554,
                "username": parsed.username or "admin",
                "password": parsed.password or "",
            }
        except Exception:
            return {}

    def _build_wsse_header(self) -> str:
        if not self.username:
            return ""
        nonce_raw = os.urandom(16)
        nonce_b64 = base64.b64encode(nonce_raw).decode("ascii")
        created = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
        digest_raw = hashlib.sha1(nonce_raw + created.encode("ascii") + self.password.encode("utf-8")).digest()
        digest_b64 = base64.b64encode(digest_raw).decode("ascii")
        return f"""
    <s:Header>
        <Security s:mustUnderstand="1" xmlns="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
            <UsernameToken>
                <Username>{self.username}</Username>
                <Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest">{digest_b64}</Password>
                <Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">{nonce_b64}</Nonce>
                <Created xmlns="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">{created}</Created>
            </UsernameToken>
        </Security>
    </s:Header>"""

    def probe_camera(self, source_type: str = None, rtsp_url: str = None, onvif_port: int = None) -> dict:
        """
        Kiểm tra trực tiếp camera hiện tại có hỗ trợ điều khiển xoay qua phần mềm (ONVIF PTZ) hay không.
        Trả về thông tin chi tiết bằng tiếng Việt để hiển thị rõ cho khách hàng.
        """
        src_type = source_type or self.config.get("camera_source_type", "usb")
        r_url = rtsp_url if rtsp_url is not None else str(self.config.get("camera_rtsp_url", "")).strip()
        self.last_probe_time = time.time()

        # Trường hợp 1: Camera USB / Webcam máy tính / Điện thoại làm Cam
        if src_type != "rtsp" or not r_url:
            self.supported = False
            self.camera_type = src_type
            self.reason_vi = (
                "Camera hiện tại là Webcam máy tính / USB cố định (không có motor xoay). "
                "Nút xoay điều khiển được làm mờ. Để xoay 360° trên phần mềm, hãy kết nối Camera IP Wifi hỗ trợ ONVIF (Imou, Tapo, Ezviz, Hikvision...)."
            )
            return self.get_status()

        parsed = self._parse_rtsp_url(r_url)
        host = parsed.get("host", "")
        if not host:
            self.supported = False
            self.reason_vi = "Đường dẫn RTSP chưa hợp lệ hoặc thiếu địa chỉ IP của camera."
            return self.get_status()

        self.host = host
        self.username = parsed.get("username", "admin")
        self.password = parsed.get("password", "")

        # Thử dò các cổng ONVIF tiêu chuẩn của các hãng phổ biến:
        # 80 (Hikvision/Dahua/Imou), 2020 (TP-Link Tapo), 8000 (Ezviz/Hikvision), 8899 (Camera ONVIF nội địa), 8080, 5000
        candidate_ports = [onvif_port] if onvif_port else [80, 2020, 8000, 8899, 8080, 5000]
        open_port = None
        for p in candidate_ports:
            if not p:
                continue
            try:
                with socket.create_connection((host, int(p)), timeout=0.6):
                    open_port = int(p)
                    break
            except Exception:
                continue

        if open_port is None:
            self.supported = False
            self.camera_type = "rtsp_fixed"
            self.reason_vi = (
                f"Đã kết nối hình ảnh Camera ({host}), nhưng không phát hiện cổng điều khiển xoay ONVIF. "
                "Camera này thuộc dòng góc cố định hoặc hãng khóa điều khiển phần mềm ngoài (như Xiaomi Mi Home). Nút xoay sẽ ở trạng thái mờ."
            )
            return self.get_status()

        self.port = open_port
        device_url = f"http://{host}:{open_port}/onvif/device_service"
        soap_body = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:tds="http://www.onvif.org/ver10/device/wsdl">
    {self._build_wsse_header()}
    <s:Body>
        <tds:GetCapabilities>
            <tds:Category>All</tds:Category>
        </tds:GetCapabilities>
    </s:Body>
</s:Envelope>"""

        try:
            resp = requests.post(
                device_url,
                data=soap_body.encode("utf-8"),
                headers={"Content-Type": "application/soap+xml; charset=utf-8"},
                timeout=2.0
            )
            text = resp.text or ""
            # Tìm địa chỉ PTZ XAddr trong phản hồi ONVIF
            ptz_match = re.search(r"<[^>]*PTZ[^>]*>.*?<[^>]*XAddr[^>]*>([^<]+)</[^>]*XAddr>", text, re.DOTALL | re.IGNORECASE)
            if ptz_match:
                self.ptz_service_url = ptz_match.group(1).strip()
                self.supported = True
                self.camera_type = "onvif_ptz"
                self.reason_vi = f"Camera IP ({host}:{open_port}) hỗ trợ xoay 360° (Chuẩn ONVIF PTZ). Bạn có thể điều khiển xoay trực tiếp trên Web và bật Auto-Tracking bám theo bé!"
                self._fetch_first_profile_token()
                return self.get_status()
            elif "PTZ" in text.upper() or open_port in (2020, 8899):
                self.ptz_service_url = f"http://{host}:{open_port}/onvif/ptz_service"
                self.supported = True
                self.camera_type = "onvif_ptz"
                self.reason_vi = f"Camera IP ({host}:{open_port}) hỗ trợ điều khiển xoay ONVIF PTZ sẵn sàng!"
                return self.get_status()
            else:
                self.supported = False
                self.camera_type = "rtsp_fixed"
                self.reason_vi = f"Camera IP ({host}:{open_port}) hoạt động tốt nhưng là dòng Camera Góc Cố Định (không có motor xoay PTZ)."
                return self.get_status()
        except Exception:
            self.supported = False
            self.camera_type = "rtsp_fixed"
            self.reason_vi = f"Camera ({host}) đang truyền hình ảnh nhưng không phản hồi giao thức xoay ONVIF PTZ. Nút xoay được làm mờ."
            return self.get_status()

    def _fetch_first_profile_token(self):
        if not self.host or not self.port:
            return
        media_url = f"http://{self.host}:{self.port}/onvif/media_service"
        soap_body = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:trt="http://www.onvif.org/ver10/media/wsdl">
    {self._build_wsse_header()}
    <s:Body>
        <trt:GetProfiles/>
    </s:Body>
</s:Envelope>"""
        try:
            resp = requests.post(media_url, data=soap_body.encode("utf-8"), headers={"Content-Type": "application/soap+xml; charset=utf-8"}, timeout=1.5)
            m = re.search(r'Profiles[^>]+token="([^"]+)"', resp.text or "")
            if m:
                self.profile_token = m.group(1)
        except Exception:
            pass

    def move(self, direction: str, speed: float = 0.5, duration: float = 0.45) -> dict:
        """
        Gửi lệnh xoay camera: direction in ('left', 'right', 'up', 'down', 'stop', 'home').
        """
        if not self.supported or not self.ptz_service_url:
            return {
                "success": False,
                "supported": False,
                "message": "Camera hiện tại không hỗ trợ motor xoay từ phần mềm (chỉ áp dụng cho Camera IP ONVIF PTZ)."
            }

        spd = max(0.1, min(1.0, float(speed)))
        vx, vy = 0.0, 0.0
        if direction == "left":
            vx = -spd
        elif direction == "right":
            vx = spd
        elif direction == "up":
            vy = spd
        elif direction == "down":
            vy = -spd
        elif direction == "stop":
            return self.stop()
        elif direction == "home":
            return self.goto_home()
        else:
            return {"success": False, "message": f"Hướng xoay không hợp lệ: {direction}"}

        soap_body = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl" xmlns:tt="http://www.onvif.org/ver10/schema">
    {self._build_wsse_header()}
    <s:Body>
        <tptz:ContinuousMove>
            <tptz:ProfileToken>{self.profile_token}</tptz:ProfileToken>
            <tptz:Velocity>
                <tt:PanTilt x="{vx:.2f}" y="{vy:.2f}"/>
            </tptz:Velocity>
        </tptz:ContinuousMove>
    </s:Body>
</s:Envelope>"""

        try:
            requests.post(
                self.ptz_service_url,
                data=soap_body.encode("utf-8"),
                headers={"Content-Type": "application/soap+xml; charset=utf-8"},
                timeout=1.5
            )
            if duration > 0:
                if self._stop_timer:
                    self._stop_timer.cancel()
                self._stop_timer = threading.Timer(duration, self.stop)
                self._stop_timer.daemon = True
                self._stop_timer.start()
            return {"success": True, "direction": direction, "speed": spd}
        except Exception as e:
            return {"success": False, "message": f"Lỗi gửi lệnh xoay PTZ: {e}"}

    def stop(self) -> dict:
        if not self.supported or not self.ptz_service_url:
            return {"success": False, "supported": False}
        soap_body = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl">
    {self._build_wsse_header()}
    <s:Body>
        <tptz:Stop>
            <tptz:ProfileToken>{self.profile_token}</tptz:ProfileToken>
            <tptz:PanTilt>true</tptz:PanTilt>
            <tptz:Zoom>true</tptz:Zoom>
        </tptz:Stop>
    </s:Body>
</s:Envelope>"""
        try:
            requests.post(self.ptz_service_url, data=soap_body.encode("utf-8"), headers={"Content-Type": "application/soap+xml; charset=utf-8"}, timeout=1.2)
            return {"success": True, "direction": "stop"}
        except Exception as e:
            return {"success": False, "message": str(e)}

    def goto_home(self) -> dict:
        if not self.supported or not self.ptz_service_url:
            return {"success": False, "supported": False, "message": "Camera không hỗ trợ xoay PTZ."}
        soap_body = f"""<?xml version="1.0" encoding="UTF-8"?>
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:tptz="http://www.onvif.org/ver20/ptz/wsdl">
    {self._build_wsse_header()}
    <s:Body>
        <tptz:GotoHomePosition>
            <tptz:ProfileToken>{self.profile_token}</tptz:ProfileToken>
        </tptz:GotoHomePosition>
    </s:Body>
</s:Envelope>"""
        try:
            requests.post(self.ptz_service_url, data=soap_body.encode("utf-8"), headers={"Content-Type": "application/soap+xml; charset=utf-8"}, timeout=1.5)
            return {"success": True, "direction": "home", "message": "Đã quay camera về vị trí trung tâm nôi!"}
        except Exception as e:
            return {"success": False, "message": str(e)}

    def auto_track_step(self, baby_box, frame_w: int, frame_h: int):
        """
        Tự động xoay nhẹ camera đuổi theo em bé nếu bé di chuyển lệch khỏi vùng trung tâm khung hình (> 22%).
        Có cooldown 2.5s giữa mỗi nhịp xoay để tránh xoay giật liên tục.
        """
        if not self.supported or not self.auto_tracking_enabled or baby_box is None:
            return
        now = time.time()
        if (now - self.last_track_move_time) < 2.5:
            return

        bx1, by1, bx2, by2 = baby_box
        cx = (bx1 + bx2) / (2.0 * max(1, frame_w))
        cy = (by1 + by2) / (2.0 * max(1, frame_h))

        dx = cx - 0.5
        dy = cy - 0.5
        if abs(dx) > 0.22:
            self.last_track_move_time = now
            direction = "right" if dx > 0 else "left"
            threading.Thread(target=self.move, args=(direction, 0.35, 0.30), daemon=True).start()
        elif abs(dy) > 0.22:
            self.last_track_move_time = now
            direction = "down" if dy > 0 else "up"
            threading.Thread(target=self.move, args=(direction, 0.35, 0.25), daemon=True).start()

    def get_status(self) -> dict:
        return {
            "supported": self.supported,
            "camera_type": self.camera_type,
            "host": self.host,
            "port": self.port,
            "auto_tracking": self.auto_tracking_enabled,
            "reason_vi": self.reason_vi,
            "compatibility_guide": {
                "supported_brands": "Imou (Ranger 2, Rex), TP-Link Tapo (C200, C210, C220), Ezviz (C6N, TY1, H6c), Hikvision, Dahua, KBVision (có chuẩn ONVIF PTZ).",
                "unsupported_brands": "Webcam laptop/USB, Camera góc cố định, hoặc Camera Xiaomi Mi Home / Tuya giá rẻ bị hãng khóa giao thức điều khiển ngoài."
            }
        }
